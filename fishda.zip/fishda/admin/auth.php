<?php
	include("lib/Auth.php");
	$a = new Auth();
	if(isset($_POST['btnLogin'])){
		$a->login($_POST['txtUsername'],$_POST['txtPassword']);
	}else{
		header("Location:logout.php");
	}
?>