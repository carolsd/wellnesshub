<?php
    include("include/header.php");
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="settings.php">ACCOUNT SETTINGS</a></li>
                <li class="active">CHANGE PASSWORD</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">CHANGE PASSWORD</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-offset-3 col-lg-6">
                <input type="hidden" name="txtAccountCode" id="txtAccountCode" value="<?php echo $_SESSION['acode'] ?>">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <form name="frmChangePassword" id="frmChangePassword" method="POST">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Current Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Current Password" class="form-control" name="txtCurrentPassword" id="txtCurrentPassword">
                                        <span class="help-block m-b-none text-danger lblCurrentPassword_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Password" class="form-control" name="txtPassword" id="txtPassword">
                                        <span class="help-block m-b-none text-danger lblPassword_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Confirm Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Confirm Password" class="form-control" name="txtConfirmPassword" id="txtConfirmPassword">
                                        <span class="help-block m-b-none text-danger lblConfirmPassword_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-4 col-lg-8">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };

    $("#frmChangePassword").submit(function(){
        if(passwordValidate() & current_passwordValidate()){
            $.ajax({
                type: "POST",
                data: { txtPassword : $("#txtPassword").val(), xPassword : true },
                url: "routes.php",
                beforeSend : function(){
                    $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    $("body .loading").append("");
                    window.location.href = "logout.php";
                }
            }).done(function(){
                $("body .loading").append("");
            });
        }
        return false;
    });

    function current_passwordValidate(){
        if($("#txtCurrentPassword").val() == ""){
            $("#txtCurrentPassword").css(errStyle);
            $(".lblCurrentPassword_Note").text("Please type password");
            $("#txtCurrentPassword").focus();
        }else if($("#txtCurrentPassword").val() != ""){
            if($("#txtCurrentPassword").val().length >= 8){
                if(passwordCheck() == '1'){
                    $("#txtCurrentPassword").css(resStyle);
                    $("#txtCurrentPassword").text("");
                    return true;
                }else{
                    $("#txtCurrentPassword").css(errStyle);
                    $(".lblCurrentPassword_Note").text("The password that you enter is invalid");
                    $("#txtCurrentPassword").focus();
                }
            }else{
                $("#txtCurrentPassword").css(errStyle);
                $(".lblCurrentPassword_Note").text("Password must be minimum 8 characters length");
                $("#txtCurrentPassword").focus();
            }
        }else{
            $("#txtCurrentPassword").css(resStyle);
            $("#txtCurrentPassword").text("");
            return true;
        }
    }

    function passwordValidate(){
        if($("#txtPassword").val() == ""){
            $("#txtPassword").css(errStyle);
            $(".lblPassword_Note").text("Please type New Password");
            $("#txtPassword").focus();
        }else if($("#txtPassword").val() != ""){
            if($("#txtPassword").val().length >= 8){
                $("#txtPassword").css(resStyle);
                $(".lblPassword_Note").text("");
                if(confirm_passwordValidate()){
                    return true;
                }else{
                    return false;
                }
            }else{
                $("#txtPassword").css(errStyle);
                $(".lblPassword_Note").text("Password must be minimum 8 characters length");
                $("#txtPassword").focus();
            }
        }else{
            $("#txtPassword").css(resStyle);
            $(".lblPassword_Note").text("");
            return true;
        }
    }
    
    function confirm_passwordValidate(){
        if($("#txtPassword").val() == $("#txtConfirmPassword").val() && $("#txtPassword").val().length >= 8){
            $("#txtConfirmPassword").css(resStyle);
            $(".lblConfirmPassword_Note").text("");
            return true;
        }else{
            $("#txtConfirmPassword").css(errStyle);
            $(".lblConfirmPassword_Note").text("New Password not match");
        }
    }

    function passwordCheck(){
        var pword;
        $.ajax({
            type: "POST",
            url: "routes.php",
            data: { txtCurrentPassword : $("#txtCurrentPassword").val(), xPassword : true },
            async: false,
            success: function(result){
                pword = result;
            }
        });
        return pword;
    }
});
</script>
<?php include("include/footer.php") ?>