<?php
	$DBHost = "localhost";
	$DBUname = "root";
	$DBPword = "";
	$DBName = "marinadb";

	$db = new mysqli($DBHost,$DBUname,$DBPword,$DBName);
	if($db->connect_errno >0){
		die('Unable to connect to database['.$db->connect_error.']');
	}
?>