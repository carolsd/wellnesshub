<?php
    include("include/header.php");
    require("lib/Reservation.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
    $reserve = new Reservation();
    $rData = $reserve->getReservationDetails($_GET['bid']);
    if($rData == 0){
        header("Location:home.php");
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li class="active">RESERVATION DETAILS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="home.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <input type="hidden" name="bid" id="bid" value="<?php echo $rData['code']; ?>"/>
                        <h3 class="box-title">REFERENCE NUMBER: <b><?php echo $rData['code']; ?></b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h4 class="box-title">CUSTOMER INFORMATION</h4>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Customer Name: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['first_name'].' '.$rData['last_name']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Mobile No: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['mobile']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Email: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['email']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h4 class="box-title">RESERVATION INFORMATION</h4>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Status: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <?php $bStatus = explode("|",$rData['status']); ?>
                                <p><?php echo "<span class='label label-".$bStatus[0]."'>".$bStatus[1]."</span>" ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Date: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['booking_date']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Time: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['booking_time']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Person(s): </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['count']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Remarks: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $rData['remarks']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-striped info serviceDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Services</th>
                                    <th>Massue</th>
                                    <th>Amount</th>
                                </tr>    
                            </thead>
                            <tbody id="tblServicesData">

                            </tbody>
                        </table>
                    </div>
                    <div class="box-footer">
                        <?php if($bStatus[1] == "VERIFIED"){ ?>
                            <button class="btn btn-primary btn-block" type="button" name="btnResAvail" id="btnResAvail">AVAIL</button>
                            <!-- <button class="btn btn-success btn-block" type="button" name="btnResNotify" id="btnResNotify">SEND SMS</button> -->
                            <button class="btn btn-warning btn-block" type="button" name="btnResRevert" id="btnResRevert">REVERT</button>
                        <?php }else if($bStatus[1] == "AVAILED"){ ?>
                            <button class="btn btn-warning btn-block" type="button" name="btnResRevert" id="btnResRevert">REVERT</button>
                        <?php }else{ ?>
                            <button class="btn btn-primary btn-block" type="button" name="btnResVerify" id="btnResVerify">VERIFY</button>
                            <button class="btn btn-danger btn-block" type="button" name="btnResCancel" id="btnResCancel">CANCEL</button>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script> -->
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script>
$(function() {
    loadDataTable();

    $("#btnResVerify").click(function(){
        $.ajax({
            type: "POST",
            data: { bid : $("#bid").val(), rtoken : 2, sms : 1 },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "details.php?bid=" + $("#bid").val();
            }
        });
    });

    // $("#btnResNotify").click(function(){
    //     $.ajax({
    //         type: "POST",
    //         data: { bid : $("#bid").val(), sms : 1 },
    //         url: "routes.php",
    //         beforeSend : function(){
    //            $("body").append("<div class='loading'>Loading&#8230;</div>");
    //         },
    //         success: function() {
    //             window.location.href = "details.php?bid=" + $("#bid").val();
    //         }
    //     });
    // });

    $("#btnResAvail").click(function(){
        $.ajax({
            type: "POST",
            data: { bid : $("#bid").val(), rtoken : 3  },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "details.php?bid=" + $("#bid").val();
            }
        });
    });

    $("#btnResCancel").click(function(){
        $.ajax({
            type: "POST",
            data: { bid : $("#bid").val(), rtoken : 0, sms : 0 },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "details.php?bid=" + $("#bid").val();
            }
        });
    });

    $("#btnResRevert").click(function(){
        $.ajax({
            type: "POST",
            data: { bid : $("#bid").val(), rtoken : 1, sms : 2 },
            url: "routes.php",
            beforeSend : function(){
               $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "details.php?bid=" + $("#bid").val();
            }
        });
    });

    function loadDataTable(){
        $.ajax({
            type: "GET",
            url: "routes.php?bid=" + $("#bid").val(),
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblServicesData").empty();
                $("#tblServicesData").append("<tr><td colspan='2'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblServicesData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#tblServicesData").append("<tr><td>" + count + "</td><td>" + value.name + "</td><td>" + value.name_of_employee + "</td><td>" + value.amount.toFixed(2) + "</td></tr>");
                    });
                }else{
                    $("#tblServicesData").empty();
                }
            }
        }).done(function(){
            var table = $('.serviceDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();
        });
    };
});
</script>
<?php include("include/footer.php") ?>