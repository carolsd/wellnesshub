<?php
    include("include/header.php");
    require("lib/Gallery.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
    $gallery = new Gallery();
    $gData = $gallery->getGalleryDetails($_GET['gid']);
    if($gData == 0){
        header("Location:gallerymanagement.php");
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li><a href="gallerymanagement.php">GALLERY MANAGEMENT</a></li>
                <li class="active">GALLERY DETAILS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="gallerymanagement.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">PHOTO DETAILS</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class='list-group ' id="galleryList">
                <div class="col-lg-6">
                    <a class="thumbnail fancybox" rel="ligthbox" href="#">
                        <img class="img-responsive" alt="" src="../theme/img/gallery/<?php echo $gData['photo']; ?>"  style="height:450px;"/>
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <button class="btn btn-danger btn-block" type="button" name="btnDelete" id="btnDelete">DELETE PHOTO</button>
                <button class="btn btn-success btn-block" type="submit" name="btnUpload" id="btnUpload">UPDATE PHOTO</button>
            </div>
        </div>
    </div>
</div>
<div id="modalUpload" class="modal fade" role="dialog" tabindex='-1'>
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data" name="frmUpload" id="frmUpload">
                <input type="hidden" name="gid" id="gid" value="<?php echo $gData['code']; ?>"/>
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Select image to upload</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="msgBox" class="form-group text-center"></div>
                        </div>
                        <div class="col-lg-offset-3 col-lg-9">
                            <div class="form-group">
                                <input type="file" name="fileToUpload" id="fileToUpload">
                                <span class="help-block m-b-none text-danger lblServiceType_Note"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-primary" type="submit" name="btnConfirmUpload" id="btnConfirmUpload">Upload</button>
                    <button class="btn btn-sm btn-default" type="button" name="btnCancel" id="btnCancel">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script>
$(function() {
    $("#btnDelete").click(function(){
        $.ajax({
            type: "POST",
            data: { galId : $("#gid").val(), gToken : 0  },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "gallerydetails.php?gid=" + $("#gid").val();
            }
        });
    });

    $("#btnUpload").click(function(e){
        e.preventDefault();
        $("#modalUpload").modal('show');
    });

    $("#frmUpload").submit(function(){
        $.ajax({
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            url: "routes.php",
            beforeSend : function(){
               $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function(data) {
                if(data != "0"){
                    window.location.href = "gallerydetails.php?gid=" + $("#gid").val();
                }else{
                    $(".loading").css('display','none');
                    $("#msgBox").append("<span class='alert text-danger'>Invalid file format</span>");
                }
            }
        });
        return false;
    });

    $("#btnCancel").click(function(e){
        e.preventDefault();
        $("#modalUpload").modal('hide');
    });
});
</script>
<?php include("include/footer.php") ?>