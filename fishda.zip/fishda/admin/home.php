<?php
    include("include/header.php");
    if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="main-panel">
        <div class="row">
            <div class="col-lg-12">
                <h3 class="pull-left">Reservation List</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table table-striped table-hover reservationDataTables">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Reference Number</th>
                                <th>Status</th>
                                <th>Customer</th>
                                <th>Mobile Number</th>
                                <th>Email</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Number of Person(s)</th>
                            </tr>
                        </thead>
                        <tbody id="tblReservationData">

                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="9">
                                    <ul class="pagination pull-right"></ul>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script>
$(function() {
    loadDataTable();

    function loadDataTable(){ // Get Reservation Booking Data
        $.ajax({
            type: "GET",
            url: "routes.php?reservation=list",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblReservationData").empty();
                $("#tblReservationData").append("<tr><td colspan='9'><div id='loader'></div></td></tr>");
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function (data) {
                var count = 0;
                $("#tblReservationData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        var bStatus = value.status.split('|');
                        $("#tblReservationData").append("<tr><td>" + count + "</td><td><a href='details.php?bid=" + value.code + "'></a>" + value.code + "</td><td><span class='label label-" + bStatus[0] + "'>" + bStatus[1] + "</span></td><td>" + value.first_name+" "+ value.last_name + "</td><td>" + value.mobile + "</td><td>" + value.email + "</td><td>" + value.booking_date + "</td><td>" + value.booking_time + "</td><td>" + value.count + "</td></tr>");
                    });
                    $('#tblReservationData tr').css('cursor','pointer');
                }else{
                    $("#tblReservationData").empty();
                }
                $(".loading").css("display" , "none");
            }
        }).done(function(){
            var table = $('.reservationDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();

            $('#tblReservationData tr').on("click",function() {
                var href = $(this).find("a").attr("href");
                if(href) {
                    $(location).attr("href",href);
                }
            });
        });
    }
});
</script>
<?php include("include/footer.php") ?>