	<div class="container">
		<footer>
			<p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
		</footer>
	</div>
</body>
</html>