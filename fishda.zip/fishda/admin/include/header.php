<?php
    session_start();
    if(isset($_SESSION['acode'])){
        include("lib/Administrator.php");
        $admin = new Administrator();
    }else{
        header("location:logout.php");
    }
?>
<!DOCTYPE html>
<html lang="en"><head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Fish SPA, Wellness">
    <meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
    <link rel="icon" href="../theme/img/fishda.png">

    <title>FISHDA WELLNESS HUB</title>

    <!-- Bootstrap core CSS -->
    <link href="../theme/css/bootstrap.css" rel="stylesheet">
    <link href="../theme/css/fishda.css" rel="stylesheet">
    <link href="../theme/css/font-awesome.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script src="../theme/js/jquery-2.1.1.js"></script>
    <script src="../theme/js/bootstrap.min.js"></script>
</head>

<body>
    <?php include("include/menu.php"); ?>