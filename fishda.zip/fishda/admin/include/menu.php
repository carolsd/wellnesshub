<nav class="navbar navbar-inverse navbar-static-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand logo" href="home.php"><img src="../theme/img/fishda_small.png"/></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-left">
                <?php
                if($_SESSION['arole'] == '2'){
                ?>
                <li><a href="home.php"><h5>DASHBOARD</h5></a></li>
                <?php }else{ ?>
                <li><a href="home.php"><h5>DASHBOARD</h5></a></li>
                <li><a href="management.php"><h5>MANAGEMENT</h5></a></li>
                <li><a href="reports.php"><h5>REPORTS</h5></a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav pull-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><h5>HI! <?php echo $admin->getFullName($_SESSION['acode']); ?> <span class="caret"></span></h5></a>
                    <ul class="dropdown-menu">
                        <li><a href="settings.php">Account Settings</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="logout.php">Log Out</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>