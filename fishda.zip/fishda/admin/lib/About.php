<?php

class About{
	public function generateAboutCode(){
        return date('ymd').strtoupper(substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
	}

	public function createNewAbout(){
		require("config/Database.php");
		$util = new Util();

		$code = $this->generateAboutCode();
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO about(idabout,code,title,content,date_created,date_modified,status) VALUES('',?,?,?,?,?,'1')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("sssss",$code,$_POST['txtTitle'],$_POST['txtContent'],$date,$date);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getAboutDetails($code));
		echo $util->createLogs($_SESSION['acode'],$logData,6);
	}

	public function getAboutList(){
		require("config/Database.php");
		session_start();
		$sql = "SELECT title,content FROM about WHERE status !=0 ORDER BY date_created DESC LIMIT 1";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($title,$content);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("title" => $title,"content" => $content);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	public function getAboutDetails($code){
		require("config/Database.php");
		$sql = "SELECT idabout,title,content,date_created,date_modified,status FROM about WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idabout,$title,$content,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("idabout" => $idabout,"title" => $title,"content" => $content,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}
	}

}

?>