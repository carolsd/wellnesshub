<?php

class Administrator{

	public function generateAdministratorCode(){
        return "UA".date('ymd').strtoupper(substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
	}

	public function createNewAccount(){
		require("config/Database.php");
		$util = new Util();

		$code = $this->generateAdministratorCode();
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO account(idaccount,code,name_of_employee,username,password,role,date_created,date_modified,status) VALUES('',?,?,?,?,?,?,?,'1')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("ssssiss",$code,$_POST['txtEmployeeName'],$_POST['txtUsername'],md5($_POST['txtPassword']),$_POST['cboRole'],$date,$date);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getAdministratorDetails($code));
		$util->createLogs($_SESSION['acode'],$logData,5);
	}

	public function getAccountList(){
		require("config/Database.php");
		session_start();
		$sql = "SELECT code,name_of_employee,username,role,status FROM account WHERE code != ? AND status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("s",$_SESSION['acode']);
		$stmt->execute();
		$stmt->bind_result($code,$name_of_employee,$username,$role,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"name_of_employee" => $name_of_employee,"username" => $username,"role" => $role,"status" => $status);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}
	
	public function getFullName($idaccount){
		require("config/Database.php");
		$sql = "SELECT name_of_employee FROM account WHERE code = ? AND status != 0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$idaccount);
		$stmt->execute();
		$stmt->bind_result($name_of_employee);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $name_of_employee;
			$stmt->close();
		}
	}

	public function getAdministratorDetails($code){
		require("config/Database.php");
		$sql = "SELECT idaccount,code,name_of_employee,username,password,role,date_created,date_modified,status FROM account WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idaccount,$code,$name_of_employee,$username,$password,$role,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("idaccount" => $idaccount,"code" => $code,"name_of_employee" => $name_of_employee,"username" => $username,"password" => $password,"role" => $role,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}
	}

	public function addAccountService(){
		require("config/Database.php");
		$services = explode("|",$_GET['chkServicesVal']);
		$date = date("Y-m-d H:i:s");
		for ($s=0; $s < count($services); $s++) { 
			$sResData = array("account" => $_GET['aid'],"services" => $services[$s],"date_created" => $date,"date_modified" => $date,"status" => "1");	

			$sql = "INSERT INTO account_services(account,service,date_created,date_modified,status) VALUES(?,?,?,?,'1')";
			$stmt = $db->prepare($sql);

			if($stmt === false){
				trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
			}

			$stmt->bind_param("ssss",$sResData['account'],$sResData['services'],$sResData['date_created'],$sResData['date_modified']);
			$stmt->execute();
		}
		$stmt->close();
	}

	public function getAdministratorDetailsServices($code){
		require("config/Database.php");
		$sql = "SELECT s.name FROM account a LEFT JOIN account_services a_s ON a.code=a_s.account JOIN services s ON s.code=a_s.service WHERE a.code = ? AND a.status !=0 GROUP BY s.name ORDER BY s.date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($name);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("name" => $name);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}

	}

	public function addAccountSchedule(){
		require("config/Database.php");
		$date = date("Y-m-d H:i:s");

		$sql = "INSERT INTO account_schedule(account,day,starttime,endtime,date_created,date_modified,status) VALUES(?,?,?,?,?,?,'1')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("ssssss",$_GET['aid'],$_GET['day'],$_GET['starttime'],$_GET['endtime'],$date,$date);
		$stmt->execute();
		$stmt->close();
	}

	public function getAdministratorDetailsSchedule($code){
		require("config/Database.php");
		$sql = "SELECT a_s.day,a_s.starttime,a_s.endtime FROM account a JOIN account_schedule a_s ON a.code=a_s.account WHERE a.code = ? AND a.status !=0 GROUP BY a_s.day ORDER BY a_s.date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($day,$starttime,$endtime);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("day" => $day,"starttime" => $starttime,"endtime" => $endtime);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}

	}

	public function updateAdministratorStatus($code,$status){
		require("config/Database.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$sql = "UPDATE account SET status = ?, date_modified = ? WHERE code = ?";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("iss",$status,$date,$code);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getAdministratorDetails($code));
		$util->createLogs($_SESSION['acode'],$logData,5);
	}
}

?>