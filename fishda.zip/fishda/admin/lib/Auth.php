<?php

class Auth{

	public function login($username,$password){
		session_start();
		require("config/Database.php");
		require("lib/Util.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$uname = $username;
		$pword = md5($password);

		$sql = "SELECT code,name_of_employee,username,role FROM account WHERE username = ? AND password = ? AND status != 0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$uname,$pword);
		$stmt->execute();
		$stmt->bind_result($code,$name_of_employee,$username,$role);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			$_SESSION['acode'] = $code;
			$_SESSION['aname'] = $name_of_employee;
			$_SESSION['arole'] = $role;

			$logData = json_encode(array('code' => $code,'name_of_employee' => $name_of_employee,'username' => $username,'ipaddress' => $_SERVER['REMOTE_ADDR'],'location' => "PHILIPPINES",'date' => $date));
			$util->createLogs($code,$logData,3);
			header("Location:home.php");
		}else{
			$_SESSION['message'] = "Unauthorized Login, Access is Denied!";
			header("Location:login.php");
		}
		$stmt->close();
	}

	public function logout(){
		session_start();
		session_destroy();
		header("location:login.php");
	}

	public function checkUsername(){
		session_start();
		require("config/Database.php");
		
		$sql = "SELECT idaccount FROM account WHERE username = ? AND status != 0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$_POST["txtUsername"]);
		$stmt->execute();
		$stmt->bind_result($idaccount);
		$stmt->store_result();
		echo $stmt->num_rows;
		$stmt->close();
	}

	public function checkPassword(){
		session_start();
		require("config/Database.php");
		$pword = md5($_POST["txtCurrentPassword"]);
		
		$sql = "SELECT idaccount FROM account WHERE password = ? AND code = ? AND status != 0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$pword,$_SESSION['acode']);
		$stmt->execute();
		$stmt->bind_result($idaccount);
		$stmt->store_result();
		echo $stmt->num_rows;
		$stmt->close();
	}

	public function changePassword(){
		session_start();
		require("config/Database.php");
		$account = new Administrator();
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$sql = "UPDATE account SET password = ?, date_modified = ? WHERE code = ?";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("sss",md5($_POST['txtPassword']),$date,$_SESSION['acode']);
		$stmt->execute();
		$stmt->close();

		$logData = json_encode($account->getAdministratorDetails($_SESSION['acode']));
		$util->createLogs($_SESSION['acode'],$logData,3);
	}

}

?>