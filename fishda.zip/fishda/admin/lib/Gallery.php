<?php

class Gallery{

	public function generateGalleryCode(){
        return "GA".date("YmdHis").substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4);
	}
	
	public function getGalleryList(){
		require("config/Database.php");
		$sql = "SELECT code,photo FROM gallery WHERE status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->execute();
		$stmt->bind_result($code,$photo);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$galData[] = array("code" => $code,"photo" => $photo);
			}
			$stmt->close();
			return json_encode($galData);
		}else{
			return json_encode($stmt->num_rows);
		}

	}

	public function getGalleryDetails($code){
		require("config/Database.php");
		$sql = "SELECT idgallery,code,photo,date_created,date_modified,status FROM gallery WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idgallery,$code,$photo,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $galData = array("idgallery" => $idgallery,"code" => $code,"photo" => $photo,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}else{
			return $stmt->num_rows;
		}
	}

	public function uploadNewPhoto(){
		require("config/Database.php");
		$util = new Util();

		$code = $this->generateGalleryCode();
		$date = date("Y-m-d H:i:s");
		$status = 1;
		$folder_name = "../theme/img/gallery";
		if(!file_exists($folder_name)){
			mkdir($folder_name);
		}

		if($_FILES['fileToUpload']['name']==null){
			$file_name = "";
			$file_mime = "";
			$file_location = "";
		}else{
			$file_name = $code.$_FILES['fileToUpload']['name'];
			$file_mime = $_FILES['fileToUpload']['type'];
			$file_location = $folder_name."/".$file_name;
			move_uploaded_file($_FILES['fileToUpload']['tmp_name'],$file_location);

			$sql = "INSERT INTO gallery(idgallery,code,photo,date_created,date_modified,status) VALUES('',?,?,?,?,?)";
			$stmt = $db->prepare($sql);

			if($stmt === false){
				trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
			}

			$stmt->bind_param("ssssi",$code,$file_name,$date,$date,$status);
			$stmt->execute();
			$stmt->close();

			session_start();
			$logData = json_encode($this->getGalleryDetails($code));
			$util->createLogs($_SESSION['acode'],$logData,4);
		}
	}

	public function updatePhoto($code){
		require("config/Database.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$folder_name = "../theme/img/gallery";
		if(!file_exists($folder_name)){
			mkdir($folder_name);
		}

		if($_FILES['fileToUpload']['name']==null){
			$file_name = "";
			$file_mime = "";
			$file_location = "";
		}else{
			$file_name = $code.$_FILES['fileToUpload']['name'];
			$file_mime = $_FILES['fileToUpload']['type'];
			$file_location = $folder_name."/".$file_name;
			move_uploaded_file($_FILES['fileToUpload']['tmp_name'],$file_location);

			$sql = "UPDATE gallery SET photo = ?, date_modified = ? WHERE code = ?";
			$stmt = $db->prepare($sql);

			if($stmt === false){
				trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
			}
			
			$stmt->bind_param("sss",$file_name,$date,$code);
			$stmt->execute();
			$stmt->close();

			session_start();
			$logData = json_encode($this->getGalleryDetails($code));
			$util->createLogs($_SESSION['acode'],$logData,4);
		}
	}

	public function updateGalleryStatus($code,$status){
		require("config/Database.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$sql = "UPDATE gallery SET status = ?, date_modified = ? WHERE code = ?";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("iss",$status,$date,$code);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getGalleryDetails($code));
		$util->createLogs($_SESSION['acode'],$logData,4);
	}
}

?>