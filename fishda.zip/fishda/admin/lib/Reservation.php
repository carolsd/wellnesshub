<?php

class Reservation{

	public function generateReservationCode(){
        // return date('ymd').strtoupper(substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
        return strtoupper(substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
	}
	
	public function getReservationList(){
		require("config/Database.php");
		$sql = "SELECT code,first_name,last_name,mobile,email,booking_date,booking_time,count,CASE WHEN status = 0 THEN 'inverse|CANCELLED' WHEN status = 1 THEN 'warning|PENDING' WHEN status = 2 THEN 'primary|VERIFIED' WHEN status = 3 THEN 'success|AVAILED' END AS bStatus FROM booking WHERE status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->execute();
		$stmt->bind_result($code,$first_name,$last_name,$mobile,$email,$booking_date,$booking_time,$count,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"first_name" => $first_name,"last_name" => $last_name,"mobile" => $mobile,"email" => $email,"booking_date" => $booking_date,"booking_time" => $booking_time,"count" => $count,"status" => $status);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	public function getReservationDetails($idreservation){
		require("config/Database.php");
		$sql = "SELECT code,first_name,last_name,mobile,email,booking_date,booking_time,count,CASE WHEN status = 0 THEN 'inverse|CANCELLED' WHEN status = 1 THEN 'warning|PENDING' WHEN status = 2 THEN 'primary|VERIFIED' WHEN status = 3 THEN 'success|AVAILED' END AS bStatus, remarks FROM booking WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$idreservation);
		$stmt->execute();
		$stmt->bind_result($code,$first_name,$last_name,$mobile,$email,$booking_date,$booking_time,$count,$status,$remarks);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("code" => $code,"first_name" => $first_name,"last_name" => $last_name,"mobile" => $mobile,"email" => $email,"booking_date" => $booking_date,"booking_time" => $booking_time,"count" => $count,"status" => $status,"remarks" => $remarks);
			$stmt->close();
		}else{
			return $stmt->num_rows;
		}
	}

	public function getReservationDetailsServices($idreservation){
		require("config/Database.php");
		$sql = "SELECT s.name,CASE WHEN bs.account = '' THEN '-' ELSE (SELECT name_of_employee FROM account WHERE code = bs.account) END name_of_employee,s.amount FROM booking b LEFT JOIN booking_services bs ON b.code=bs.booking LEFT JOIN services s ON bs.service=s.code LEFT JOIN account a ON bs.account=a.code WHERE b.code = ? AND b.status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$idreservation);
		$stmt->execute();
		$stmt->bind_result($name,$name_of_employee,$amount);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("name" => $name,"name_of_employee" => $name_of_employee,"amount" => $amount);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}

	}

	public function getReservationReport($status,$date_from,$date_to){
		require("config/Database.php");
		if($status == "all"){
			$statusQuery = "";
		}else{
			$statusQuery = " AND status = ".$status;
		}
		$sql = "SELECT code,first_name,last_name,mobile,email,booking_date,booking_time,count,CASE WHEN status = 0 THEN 'CANCELLED' WHEN status = 1 THEN 'PENDING' WHEN status = 2 THEN 'VERIFIED' WHEN status = 3 THEN 'AVAILED' END AS bStatus FROM booking WHERE (DATE_FORMAT(date_created,'%Y-%m-%d') BETWEEN ? AND ?)".$statusQuery;
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$date_from,$date_to);
		$stmt->execute();
		$stmt->bind_result($code,$first_name,$last_name,$mobile,$email,$booking_date,$booking_time,$count,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"first_name" => $first_name,"last_name" => $last_name,"mobile" => $mobile,"email" => $email,"booking_date" => $booking_date,"booking_time" => $booking_time,"count" => $count,"status" => $status);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	public function getReservationReportExport($status,$date_from,$date_to){
		require("config/Database.php");
		require("lib/ExcelExport.php");
		if($status == "all"){
			$statusQuery = "";
		}else{
			$statusQuery = " AND status = ".$status;
		}
		$sql = "SELECT code,first_name,last_name,mobile,email,booking_date,booking_time,count,CASE WHEN status = 0 THEN 'CANCELLED' WHEN status = 1 THEN 'PENDING' WHEN status = 2 THEN 'VERIFIED' WHEN status = 3 THEN 'AVAILED' END AS bStatus FROM booking WHERE (DATE_FORMAT(date_created,'%Y-%m-%d') BETWEEN ? AND ?)".$statusQuery;
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$date_from,$date_to);
		$stmt->execute();
		$stmt->bind_result($code,$first_name,$last_name,$mobile,$email,$booking_date,$booking_time,$count,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"first_name" => $first_name,"last_name" => $last_name,"mobile" => $mobile,"email" => $email,"booking_date" => $booking_date,"booking_time" => $booking_time,"count" => $count,"status" => $status);
			}
			$stmt->close();
		}else{
			$resData = "";
		}
		
		session_start();
		$exportExcel = new ExcelExport();
		$exportExcel->extractFileHeader(date("Ydm").$_SESSION['acode'].".xls");
		$exportExcel->extractFileBOF();
		$i = 0;
		$a = 1;
		$b = 0;
		foreach ($resData[0] as $key => $value) {
			$exportExcel->xlsWriteLabel(0,$i,strtoupper($key));
			$i++;
		}

		while($b < count($resData)) {
			$exportExcel->xlsWriteLabel($a,0,$resData[$b]['code']);
			$exportExcel->xlsWriteLabel($a,1,$resData[$b]['first_name']);
			$exportExcel->xlsWriteLabel($a,2,$resData[$b]['last_name']);
			$exportExcel->xlsWriteLabel($a,3,$resData[$b]['mobile']);
			$exportExcel->xlsWriteLabel($a,4,$resData[$b]['email']);
			$exportExcel->xlsWriteLabel($a,5,$resData[$b]['booking_date']);
			$exportExcel->xlsWriteLabel($a,6,$resData[$b]['booking_time']);
			$exportExcel->xlsWriteLabel($a,7,$resData[$b]['count']);
			$exportExcel->xlsWriteLabel($a,8,$resData[$b]['status']);
			$b++;
			$a++;
		}
		
		$exportExcel->extractFileEOF();
	}

	public function updateReservationStatus($idreservation,$status){
		require("config/Database.php");
		$util = new Util();
		$sms = new Sms();

		$date = date("Y-m-d H:i:s");
		$sql = "UPDATE booking SET status = ?, date_modified = ? WHERE code = ?";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("iss",$status,$date,$idreservation);
		$stmt->execute();
		$stmt->close();

		// if($status == "3"){
			// $sms->notifyAvailed($idreservation);
		// }else 

		session_start();
		$logData = json_encode($this->getReservationDetails($idreservation));
		$util->createLogs($_SESSION['acode'],$logData,1);
	}

}

?>