<?php

class Services{

	public function generateServiceCode(){
        return "SE".date('ymd').strtoupper(substr(str_shuffle(time().'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 4));
	}

	public function createNewService(){
		require("config/Database.php");
		$util = new Util();

		$code = $this->generateServiceCode();
		$date = date("Y-m-d H:i:s");
		$status = 2;
		$sql = "INSERT INTO services(idservices,code,type,name,description,timerange,amount,date_created,date_modified,status) VALUES('',?,?,?,?,?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("ssssssssi",$code,$_POST['cboServiceType'],$_POST['txtServiceName'],$_POST['txtServiceDescription'],$_POST['txtTimeRange'],$_POST['txtAmount'],$date,$date,$status);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getServiceDetails($code));
		$util->createLogs($_SESSION['acode'],$logData,4);
	}
	
	public function getServicesList(){
		require("config/Database.php");
		$sql = "SELECT code,type,name,description,photo,amount,timerange,CASE WHEN status = 0 THEN 'inverse|DEACTIVATED' WHEN status = 1 THEN 'success|ACTIVE' WHEN status = 2 THEN 'warning|PENDING' END AS sStatus FROM services WHERE status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->execute();
		$stmt->bind_result($code,$type,$name,$description,$photo,$amount,$timerange,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"amount" => $amount,"timerange" => $timerange,"status" => $status);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}

	}

	public function getServiceDetails($code){
		require("config/Database.php");
		$sql = "SELECT idservices,code,type,name,description,photo,timerange,amount,date_created,date_modified,CASE WHEN status = 0 THEN 'inverse|DEACTIVATED' WHEN status = 1 THEN 'success|ACTIVE' WHEN status = 2 THEN 'warning|PENDING' END AS sStatus FROM services WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idservices,$code,$type,$name,$description,$photo,$timerange,$amount,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("idservices" => $idservices,"code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"timerange" => $timerange,"amount" => $amount,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}else{
			return $stmt->num_rows;
		}
	}

	public function uploadPhoto($code){
		require("config/Database.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$folder_name = "../theme/img/services";
		if(!file_exists($folder_name)){
			mkdir($folder_name);
		}

		if($_FILES['fileToUpload']['name']==null){
			$file_name = "";
			$file_mime = "";
			$file_location = "";
		}else{
			$file_name = $code.$_FILES['fileToUpload']['name'];
			$file_mime = $_FILES['fileToUpload']['type'];
			$file_location = $folder_name."/".$file_name;
			move_uploaded_file($_FILES['fileToUpload']['tmp_name'],$file_location);

			$sql = "UPDATE services SET status = '1', photo = ?, date_modified = ? WHERE code = ?";
			$stmt = $db->prepare($sql);

			if($stmt === false){
				trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
			}
			
			$stmt->bind_param("sss",$file_name,$date,$code);
			$stmt->execute();
			$stmt->close();

			session_start();
			$logData = json_encode($this->getServiceDetails($code));
			$util->createLogs($_SESSION['acode'],$logData,4);
		}
	}

	function getServices($type){
		require("config/Database.php");
		$sql = "SELECT code,type,name,description,photo,amount,timerange FROM services WHERE type = ? AND status !=2 AND status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$type);
		$stmt->execute();
		$stmt->bind_result($code,$type,$name,$description,$photo,$amount,$timerange);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"amount" => $amount,"timerange" => $timerange);
			}
			$stmt->close();
		}else{
			$resData = "";
		}

		return json_encode($resData);
	}

	public function updateServiceStatus($code,$status){
		require("config/Database.php");
		$util = new Util();

		$date = date("Y-m-d H:i:s");
		$sql = "UPDATE services SET status = ?, date_modified = ? WHERE code = ?";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("iss",$status,$date,$code);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getServiceDetails($code));
		$util->createLogs($_SESSION['acode'],$logData,4);
	}
}

?>