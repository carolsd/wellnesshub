<?php

class Sms{

	public function createNewSmsGateway(){
		require("config/Database.php");
		$util = new Util();

		$code = $_POST['txtDeviceNumber'];
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO smsgateway(idsmsgateway,device,email,password,date_created,date_modified,status) VALUES('',?,?,?,?,?,'1')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("sssss",$code,$_POST['txtEmail'],$_POST['txtPassword'],$date,$date);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode($this->getSmsGatewayDetails($code));
		echo $util->createLogs($_SESSION['acode'],$logData,6);
	}

	public function getSmsGatewayList(){
		require("config/Database.php");
		session_start();
		$sql = "SELECT device,email FROM smsgateway WHERE status !=0 ORDER BY date_created DESC LIMIT 1";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($device,$email);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("device" => $device,"email" => $email);
			}
			$stmt->close();
			return json_encode($resData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	public function getSmsGatewayDetails($code){
		require("config/Database.php");
		$sql = "SELECT idsmsgateway,device,email,password,date_created,date_modified,status FROM smsgateway WHERE device = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idsmsgateway,$device,$email,$password,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("idsmsgateway" => $idsmsgateway,"device" => $device,"email" => $email,"password" => $password,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}
	}

	public function smsGatewayAuth(){
		require("config/Database.php");
		$sql = "SELECT device,email,password FROM smsgateway ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($device,$email,$password);
		$stmt->store_result();
		$stmt->fetch();
		$stmt->close();
		return array('device' => $device,'email' => $email,'password' => $password);
	}

	public function notifyVerified($idreservation){
		require("lib/SMS/SmsGateway.php");
		$util = new Util();

		$reservation = new Reservation();
		$smsAuth = $this->smsGatewayAuth();
		$smsGateway= new SmsGateway($smsAuth['email'],$smsAuth['password']);
		$reserve = $reservation->getReservationDetails($idreservation);

		$to = str_replace(" ","",str_replace("+63","0",$reserve['mobile']));
		$message="Hi! ".$reserve['first_name']." ".$reserve['last_name']." your reservation with reference number ".$reserve['code']." for ".$reserve['booking_date']." ".$reserve['booking_time']." for FISDA WELLNESS SPA has been verified";
		$options=array('send_at' => strtotime('+1 seconds'),'expires_at' => strtotime('+1 hour'));

		$response = $smsGateway->sendMessageToNumber($to, $message, $smsAuth['device'], $options);
		$smsResData = array("to" => $to,"message" => $message,"device" => $smsAuth['device'],"options" => $options,"response" => $response);
		$util->createLogs($reserve['code'],json_encode($smsResData),6);

	}

	public function notifyAvailed($idreservation){
		require("lib/SMS/SmsGateway.php");
		$util = new Util();

		$reservation = new Reservation();
		$smsAuth = $this->smsGatewayAuth();
		$smsGateway= new SmsGateway($smsAuth['email'],$smsAuth['password']);
		$reserve = $reservation->getReservationDetails($idreservation);

		$to = str_replace(" ","",str_replace("+63","0",$reserve['mobile']));
		$message="Hi! ".$reserve['first_name']." ".$reserve['last_name']." your reservation with reference number ".$reserve['code']." has been availed. Thank you for using FISDA WELLNESS SPA service";
		$options=array('send_at' => strtotime('+1 seconds'),'expires_at' => strtotime('+1 hour'));

		$response = $smsGateway->sendMessageToNumber($to, $message, $smsAuth['device'], $options);
		$smsResData = array("to" => $to,"message" => $message,"device" => $smsAuth['device'],"options" => $options,"response" => $response);
		$util->createLogs($reserve['code'],json_encode($smsResData),6);

	}

	public function notifyCancelation($idreservation){
		require("lib/SMS/SmsGateway.php");
		$util = new Util();
		
		$reservation = new Reservation();
		$smsAuth = $this->smsGatewayAuth();
		$smsGateway= new SmsGateway($smsAuth['email'],$smsAuth['password']);
		$reserve = $reservation->getReservationDetails($idreservation);

		$to = str_replace(" ","",str_replace("+63","0",$reserve['mobile']));
		$message="Hi! ".$reserve['first_name']." ".$reserve['last_name']." your reservation with reference number ".$reserve['code']." for ".$reserve['booking_date']." ".$reserve['booking_time']." for FISDA WELLNESS SPA has been cancelled";
		$options=array('send_at' => strtotime('+1 seconds'),'expires_at' => strtotime('+1 hour'));

		$response = $smsGateway->sendMessageToNumber($to, $message, $smsAuth['device'], $options);
		$smsResData = array("to" => $to,"message" => $message,"device" => $smsAuth['device'],"options" => $options,"response" => $response);
		$util->createLogs($reserve['code'],json_encode($smsResData),6);
	}

	public function notifyRevert($idreservation){
		require("lib/SMS/SmsGateway.php");
		$util = new Util();

		$reservation = new Reservation();
		$smsAuth = $this->smsGatewayAuth();
		$smsGateway= new SmsGateway($smsAuth['email'],$smsAuth['password']);
		$reserve = $reservation->getReservationDetails($idreservation);

		$to = str_replace(" ","",str_replace("+63","0",$reserve['mobile']));
		$message="Hi! ".$reserve['first_name']." ".$reserve['last_name']." your reservation with reference number ".$reserve['code']." for FISDA WELLNESS SPA has been reverted due to technical issue.";
		$options=array('send_at' => strtotime('+1 seconds'),'expires_at' => strtotime('+1 hour'));

		$response = $smsGateway->sendMessageToNumber($to, $message, $smsAuth['device'], $options);
		$smsResData = array("to" => $to,"message" => $message,"device" => $smsAuth['device'],"options" => $options,"response" => $response);
		$util->createLogs($reserve['code'],json_encode($smsResData),6);

	}

}

?>