<?php

class Util{
	
	public function createLogs($code,$log,$status){
		require("config/Database.php");
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO logs(code,log,date_created,date_modified,status) VALUES(?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ssssi",$code,$log,$date,$date,$status);
		$stmt->execute();
		$stmt->close();
	}

	public function getFromYear(){
		require("config/Database.php");
		session_start();
		$sql = "SELECT DATE_FORMAT(date_created,'%Y') AS year FROM booking WHERE status !=0 GROUP BY DATE_FORMAT(date_created,'%Y') ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($year);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("yearFrom" => $year);
			}
			$stmt->close();
			return $resData;
		}else{
			return $stmt->num_rows;
		}
	}

	public function getToYear(){
		require("config/Database.php");
		session_start();
		$sql = "SELECT DATE_FORMAT(date_created,'%Y') AS year FROM booking WHERE status !=0 GROUP BY DATE_FORMAT(date_created,'%Y') ORDER BY date_created ASC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($year);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("yearTo" => $year);
			}
			$stmt->close();
			return $resData;
		}else{
			return $stmt->num_rows;
		}
	}

	public function getWebVisitorReport($date_from,$date_to){
		require("config/Database.php");
		
		$sql = "SELECT code,log,DATE_FORMAT(date_created,'%Y-%m-%d') AS date_created,COUNT(code) AS count FROM logs WHERE status = 2 AND (DATE_FORMAT(date_created,'%Y-%m-%d') BETWEEN ? AND ?) GROUP BY DATE_FORMAT(date_created,'%Y-%m-%d')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$date_from,$date_to);
		$stmt->execute();
		$stmt->bind_result($code,$log,$date_created,$count);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			echo $log;
			while($stmt->fetch()){
				// $logData = implode("|",json_decode($log,true));
				$webvisitData[] = array("code" => $code,"log" => $log,"count" => $count,"date_created" => $date_created);
			}
			$stmt->close();
			return json_encode($webvisitData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	public function getWebVisitorReportExcel($date_from,$date_to){
		require("config/Database.php");
		require("lib/ExcelExport.php");
		
		$sql = "SELECT code,log,DATE_FORMAT(date_created,'%Y-%m-%d') AS date_created,COUNT(code) AS count FROM logs WHERE status = 2 AND (DATE_FORMAT(date_created,'%Y-%m-%d') BETWEEN ? AND ?) GROUP BY DATE_FORMAT(date_created,'%Y-%m-%d')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$date_from,$date_to);
		$stmt->execute();
		$stmt->bind_result($code,$log,$date_created,$count);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$logData = implode("|",json_decode($log,true));
				$webvisitData[] = array("code" => $code,"log" => $logData,"date_created" => $date_created,"count" => $count);
			}
			$stmt->close();
		}else{
			$webvisitData = "";
		}

		session_start();
		$exportExcel = new ExcelExport();
		$exportExcel->extractFileHeader(date("Ydm").$_SESSION['acode'].".xls");
		$exportExcel->extractFileBOF();
		$i = 0;
		$a = 1;
		$b = 0;
		foreach ($webvisitData[0] as $key => $value) {
			$exportExcel->xlsWriteLabel(0,$i,strtoupper($key));
			$i++;
		}

		while($b < count($webvisitData)) {
			$exportExcel->xlsWriteLabel($a,0,$webvisitData[$b]['code']);
			$exportExcel->xlsWriteLabel($a,1,$webvisitData[$b]['log']);
			$exportExcel->xlsWriteLabel($a,2,$webvisitData[$b]['date_created']);
			$exportExcel->xlsWriteLabel($a,3,$webvisitData[$b]['count']);
			$b++;
			$a++;
		}
		
		$exportExcel->extractFileEOF();
	}
}

?>