<?php
	session_start();
	if(isset($_SESSION['acode'])){
		header("Location:logout.php");
	}
?>
<!DOCTYPE html>
<html lang="en"><head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Lady Christin Friginal, Sukpal Deol">
	<link rel="icon" href="../theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<!-- Bootstrap core CSS -->
	<link href="../theme/css/bootstrap.css" rel="stylesheet">
	<link href="../theme/css/fishdaweb.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<div class="container">
		<div class="login-panel">
	    	<div class="row">
	    		<div class="col-lg-offset-4 col-lg-4">
	    			<div class="brand">
				        <img src="../theme/img/fishda.png"/>
				    </div>
	    			<?php
	    				echo isset($_SESSION['message']) ? '<span class="alert alert-danger col-lg-12 text-center">'.$_SESSION['message'].'</span>' : "";
	    				unset($_SESSION['message']);
	    			?>
	    			<form action="auth.php" method="post" autocomplete="off">
		                <div class="form-group">
		                    <input type="text" name="txtUsername" id="txtUsername" class="form-control" placeholder="Username">
		                    <span class="text-danger lblUsername_Note"></span>
		                </div>

		                <div class="form-group">
		                    <input type="password" name="txtPassword" id="txtPassword" class="form-control" placeholder="Password">
		                    <span class="text-danger lblPassword_Note"></span>
		                </div>
		                <div class="row">
		                    <div class="col-xs-12">
		                        <button type="submit" class="btn btn-primary btn-block" name="btnLogin" id="btnLogin">Log In</button>
		                        <a href="/fishda" class="btn btn-success btn-block">Back to Fishda Website</a>
		                    </div>
		                </div>
		            </form>
	    		</div>
	    	</div>
		</div>
    </div>
	<div class="container">
	    <footer>
			<p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
		</footer>
    </div>
</body>
</html>