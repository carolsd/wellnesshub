<?php
	include("lib/Auth.php");
	$a = new Auth();
	$a->logout();
?>