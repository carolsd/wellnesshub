<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li class="active">MANAGEMENT</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="home.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>    
        <div class="row">
            <div class="col-lg-12">
                <h3 class="pull-left">Management</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <a href="servicesmanagement.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-lock"></i>
                        </div>
                        <div class="options">
                            <h4>Services Management</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-3">
                <a href="usermanagement.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-user"></i>
                        </div>
                        <div class="options">
                            <h4>User Management</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-3">
                <a href="smsmanagement.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-mobile"></i>
                        </div>
                        <div class="options">
                            <h4>SMS Management</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-3">
                <a href="gallerymanagement.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-photo"></i>
                        </div>
                        <div class="options">
                            <h4>Gallery Management</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-3">
                <a href="webmanagement.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-file"></i>
                        </div>
                        <div class="options">
                            <h4>About Content Management</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>    
    </div>    
</div>
<?php include("include/footer.php") ?>