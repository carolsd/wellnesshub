<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="main-panel">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">UPLOAD NEW PHOTO</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-offset-3 col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <form name="frmServices" id="frmServices" method="POST" autocomplete="off">
                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-9">
                                        <label class="control-label">Select image to upload:</label>
                                        <input type="file" name="fileToUpload" id="fileToUpload">
                                        <span class="help-block m-b-none text-danger lblServiceType_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-9">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputNum($("#txtAmount"));

    $("#frmServices").submit(function(){
        if(validateAmount() & validateServiceDescription() & validateServiceName() & validateServiceType()){
            $.ajax({
                type: "POST",
                data: { cboServiceType : $("#cboServiceType").val(), txtServiceName : $("#txtServiceName").val(), txtServiceDescription : $("#txtServiceDescription").val(), txtAmount : $("#txtAmount").val(), txtTimeRange : "", regServ : true },
                url: "routes.php",
                beforeSend : function(){
                   $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "servicesmanagement.php";
                }
            });
        }
        return false;
    });

    function validateServiceType(){
        if($("#cboServiceType").val() == ""){
            $("#cboServiceType").css(errStyle);
            $(".lblServiceType_Note").text("Please select service type");
            $("#cboServiceType").focus();
        }else{
            $("#cboServiceType").css(resStyle);
            $(".lblServiceType_Note").text("");
            return true;
        }
    }

    function validateServiceName(){
        if($("#txtServiceName").val() == ""){
            $("#txtServiceName").css(errStyle);
            $(".lblServiceName_Note").text("Please type service name");
        }else{
            $("#txtServiceName").css(resStyle);
            $(".lblServiceName_Note").text("");
            return true;
        }
    }

    function validateServiceDescription(){
        if($("#txtServiceDescription").val() == ""){
            $("#txtServiceDescription").css(errStyle);
            $(".lblServiceDescription_Note").text("Please type service description");
        }else{
            $("#txtServiceDescription").css(resStyle);
            $(".lblServiceDescription_Note").text("");
            return true;
        }
    }

    function validateAmount(){
        if($("#txtAmount").val() == ""){
            $("#txtAmount").css(errStyle);
            $(".lblAmount_Note").text("Please type amount");
        }else{
            $("#txtAmount").css(resStyle);
            $(".lblAmount_Note").text("");
            return true;
        }
    }

    function validateTimeRange(){
        if($("#txtTimeRange").val() == ""){
            $("#txtTimeRange").css(errStyle);
            $(".lblTimeRange_Note").text("Please select time range");
        }else{
            $("#txtTimeRange").css(resStyle);
            $(".lblTimeRange_Note").text("");
            return true;
        }
    }
});
</script>
<?php include("include/footer.php") ?>