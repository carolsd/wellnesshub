<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li><a href="servicesmanagement.php">SERVICES MANAGEMENT</a></li>
                <li class="active">NEW SERVICE</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">REGISTER NEW SERVICE</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-offset-3 col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <form name="frmServices" id="frmServices" method="POST" autocomplete="off">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Service Type</label>
                                    <div class="col-lg-9">
                                        <select class="form-control" name="cboServiceType" id="cboServiceType">
                                            <option value="">- SELECT SERVICE TYPE -</option>
                                            <option value="1">BASIC</option>
                                            <option value="2">PACKAGE</option>
                                        </select>
                                        <span class="help-block m-b-none text-danger lblServiceType_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Service Name</label>
                                    <div class="col-lg-9">
                                        <input type="text" placeholder="Service Name" class="form-control text-caps" name="txtServiceName" id="txtServiceName"/>
                                        <span class="help-block m-b-none text-danger lblServiceName_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Service Description</label>
                                    <div class="col-lg-9">
                                        <textarea type="text" placeholder="Service Description" class="form-control" name="txtServiceDescription" id="txtServiceDescription"></textarea>
                                        <span class="help-block m-b-none text-danger lblServiceDescription_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Amount</label>
                                    <div class="col-lg-9">
                                        <input type="text" placeholder="Amount" class="form-control" name="txtAmount" id="txtAmount"/>
                                        <span class="help-block m-b-none text-danger lblAmount_Note"></span>
                                    </div>
                                </div>
                                <!-- <div class="form-group">
                                    <label class="col-lg-3 control-label">Time Range</label>
                                    <div class="col-lg-9">
                                        <input type="text" class="form-control" id="txtTimeRange" name="txtTimeRange" placeholder="HH:MM:SS"/>
                                        <span class="help-block text-danger lblTimeRange_Note"></span>
                                    </div>
                                </div> -->
                                <div class="form-group">
                                    <div class="col-lg-offset-3 col-lg-9">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputNum($("#txtAmount"));

    $("#frmServices").submit(function(){
        if(validateAmount() & validateServiceDescription() & validateServiceName() & validateServiceType()){
            $.ajax({
                type: "POST",
                data: { cboServiceType : $("#cboServiceType").val(), txtServiceName : $("#txtServiceName").val(), txtServiceDescription : $("#txtServiceDescription").val(), txtAmount : $("#txtAmount").val(), txtTimeRange : "", regServ : true },
                url: "routes.php",
                beforeSend : function(){
                   $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "servicesmanagement.php";
                }
            });
        }
        return false;
    });

    function validateServiceType(){
        if($("#cboServiceType").val() == ""){
            $("#cboServiceType").css(errStyle);
            $(".lblServiceType_Note").text("Please select service type");
            $("#cboServiceType").focus();
        }else{
            $("#cboServiceType").css(resStyle);
            $(".lblServiceType_Note").text("");
            return true;
        }
    }

    function validateServiceName(){
        if($("#txtServiceName").val() == ""){
            $("#txtServiceName").css(errStyle);
            $(".lblServiceName_Note").text("Please type service name");
        }else{
            $("#txtServiceName").css(resStyle);
            $(".lblServiceName_Note").text("");
            return true;
        }
    }

    function validateServiceDescription(){
        if($("#txtServiceDescription").val() == ""){
            $("#txtServiceDescription").css(errStyle);
            $(".lblServiceDescription_Note").text("Please type service description");
        }else{
            $("#txtServiceDescription").css(resStyle);
            $(".lblServiceDescription_Note").text("");
            return true;
        }
    }

    function validateAmount(){
        if($("#txtAmount").val() == ""){
            $("#txtAmount").css(errStyle);
            $(".lblAmount_Note").text("Please type amount");
        }else{
            $("#txtAmount").css(resStyle);
            $(".lblAmount_Note").text("");
            return true;
        }
    }

    function validateTimeRange(){
        if($("#txtTimeRange").val() == ""){
            $("#txtTimeRange").css(errStyle);
            $(".lblTimeRange_Note").text("Please select time range");
        }else{
            $("#txtTimeRange").css(resStyle);
            $(".lblTimeRange_Note").text("");
            return true;
        }
    }
});
</script>
<?php include("include/footer.php") ?>