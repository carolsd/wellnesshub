<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li class="active">REPORTS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="home.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <h3 class="pull-left">Reports</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <a href="reservationreport.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-book"></i>
                        </div>
                        <div class="options">
                            <h4>Reservation Report</h4>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-sm-3">
                <a href="visitorsreport.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-users"></i>
                        </div>
                        <div class="options">
                            <h4>Web Visitors Report</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>    
    </div>    
</div>
<?php include("include/footer.php") ?>