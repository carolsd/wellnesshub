<?php
	require("lib/Reservation.php");
	require("lib/Services.php");
	require("lib/Gallery.php");
	require("lib/Administrator.php");
	require("lib/Auth.php");
	require("lib/Sms.php");
	require("lib/About.php");
	require("lib/Util.php");
	$reserve = new Reservation();
	$services = new Services();
	$gallery = new Gallery();
	$account = new Administrator();
	$auth = new Auth();
	$sms = new Sms();
	$about = new About();
	$util = new Util();

	if(isset($_GET['reservation'])){
		if($_GET['reservation'] == "list"){
			echo $reserve->getReservationList();
		}else if($_GET['reservation'] == "report"){
			if($_GET['rStatus'] == "all"){
				$rStatus = "all";
			}else if($_GET['rStatus'] == 1){
				$rStatus = 1;
			}else if($_GET['rStatus'] == 2){
				$rStatus = 2;
			}else if($_GET['rStatus'] == 3){
				$rStatus = 3;
			}
			echo $reserve->getReservationReport($rStatus,$_GET['dateFrom'],$_GET['dateTo']);
		}else if($_GET['reservation'] == "export"){
			if($_GET['rStatus'] == "all"){
				$rStatus = "all";
			}else if($_GET['rStatus'] == 1){
				$rStatus = 1;
			}else if($_GET['rStatus'] == 2){
				$rStatus = 2;
			}else if($_GET['rStatus'] == 3){
				$rStatus = 3;
			}
			echo $reserve->getReservationReportExport($rStatus,$_GET['dateFrom'],$_GET['dateTo']);
		}
	}else if(isset($_GET['services'])){
		if($_GET['services'] == "list"){
			echo $services->getServicesList();
		}
	}else if(isset($_GET['gallery'])){
		if($_GET['gallery'] == "list"){
			echo $gallery->getGalleryList();
		}
	}else if(isset($_POST['sUid'])){
		if($_FILES['fileToUpload']['type'] == 'image/jpeg' || $_FILES['fileToUpload']['type'] == 'image/png'){
			$services->uploadPhoto($_POST['sUid']);
		}else{
			echo "Invalid file format.";
		}
	}else if(isset($_GET['sms'])){
		if($_GET['sms'] == "list"){
			echo $sms->getSmsGatewayList();
		}
	}else if(isset($_GET['about'])){
		if($_GET['about'] == "list"){
			echo $about->getAboutList();
		}
	}else if(isset($_POST['regServ'])){
		$services->createNewService();
	}else if(isset($_POST['gUp'])){
		if($_FILES['fileToUpload']['type'] == 'image/jpeg' || $_FILES['fileToUpload']['type'] == 'image/png'){
			$gallery->uploadNewPhoto();
		}else{
			echo "0";
		}
	}else if(isset($_POST['gid'])){
		if($_FILES['fileToUpload']['type'] == 'image/jpeg' ||  $_FILES['fileToUpload']['type'] == 'image/png'){
			$gallery->updatePhoto($_POST['gid']);
		}else{
			echo "0";
		}
	}else if(isset($_POST['gToken'])){
		if($_POST['gToken'] == 0){
			$gallery->updateGalleryStatus($_POST['galId'],$_POST['gToken']);
		}
	}else if(isset($_POST['sid'])){
		if(isset($_POST['sToken'])){
			$services->updateServiceStatus($_POST['sid'],$_POST['sToken']);
		}
	}else if(isset($_POST['regUser'])){
		$account->createNewAccount();
	}else if(isset($_POST['regSms'])){
		$sms->createNewSmsGateway();
	}else if(isset($_POST['regAbout'])){
		$about->createNewAbout();
	}else if(isset($_POST['xPassword'])){
		if(isset($_POST['txtPassword'])){
			$auth->changePassword();
		}else if(isset($_POST['txtCurrentPassword'])){
			$auth->checkPassword();
		}
	}else if(isset($_POST['nUsername'])){
		if(isset($_POST['txtUsername'])){
			$auth->checkUsername();
		}
	}else if(isset($_GET['account'])){
		if($_GET['account'] == "list"){
			echo $account->getAccountList();
		}
	}else if(isset($_GET['aid'])){
		if(isset($_GET['data'])){
			if($_GET['data'] == 'services'){
				echo $account->getAdministratorDetailsServices($_GET['aid']);
			}else if($_GET['data'] == 'schedule'){
				echo $account->getAdministratorDetailsSchedule($_GET['aid']);
			}
		}else if(isset($_GET['atoken'])){
			echo $account->updateAdministratorStatus($_GET['aid'],$_GET['atoken']);
		}else if(isset($_GET['aServices'])){
			echo $account->addAccountService();
		}else if(isset($_GET['aSchedule'])){
			echo $account->addAccountSchedule();
		}
	}else if(isset($_GET['bid'])){
		echo $reserve->getReservationDetailsServices($_GET['bid']);
	}else if(isset($_POST['bid'])){
		if(isset($_POST['rtoken'])){
			if(isset($_POST['sms'])){
				if($_POST['sms'] == 1){
					$sms->notifyVerified($_POST['bid']);
				}else if($_POST['sms'] == 2){
					$sms->notifyRevert($_POST['bid']);
				}else if($_POST['sms'] == 0){
					$sms->notifyCancelation($_POST['bid']);
				}
			}
			$reserve->updateReservationStatus($_POST['bid'],$_POST['rtoken']);
		}
	}else if(isset($_GET['webvisit'])){
		if($_GET['webvisit'] == "report"){
			echo $util->getWebVisitorReport($_GET['dateFrom'],$_GET['dateTo']);
		}else if($_GET['webvisit'] == "export"){
			echo $util->getWebVisitorReportExcel($_GET['dateFrom'],$_GET['dateTo']);
		}
	}
?>