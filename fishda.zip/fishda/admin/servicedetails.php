<?php
    include("include/header.php");
    require("lib/Services.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
    $service = new Services();
    $sData = $service->getServiceDetails($_GET['sid']);
    if($sData == 0){
        header("Location:servicesmanagement.php");
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li><a href="servicesmanagement.php">SERVICES MANAGEMENT</a></li>
                <li class="active">SERVICE DETAILS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="servicesmanagement.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <input type="hidden" name="sid" id="sid" value="<?php echo $sData['code']; ?>"/>
                        <h3 class="box-title">SERVICE DETAILS</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Type: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo ($sData['type'] == 1) ? "Basic Services" : "Package Services"; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Name: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $sData['name']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Description: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $sData['description']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Amount</b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo number_format($sData['amount'],2); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="box box-primary">
                    <?php $sStatus = explode("|",$sData['status']); ?>
                    <?php if($sStatus[1] == "ACTIVE"){ ?>
                        <div class="box-body">
                            <div class="form-group">
                                <img src="../theme/img/services/<?php echo $sData['photo']; ?>" class="img-responsive"/>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button class="btn btn-danger btn-block" type="button" name="btnDeactivate" id="btnDeactivate">DEACTIVATE SERVICE</button>
                        </div>
                    <?php }else{ ?>
                        <form method="POST" enctype="multipart/form-data" name="frmUpdate" id="frmUpdate">
                            <input type="hidden" name="sUid" id="sUid" value="<?php echo $sData['code']; ?>"/>
                            <div class="box-body">
                                <div class="form-group">
                                    <label class="control-label">Select image to upload:</label>
                                    <input type="file" name="fileToUpload" id="fileToUpload">
                                    <span class="help-block m-b-none text-danger lblServiceType_Note"></span>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button class="btn btn-success btn-block" type="submit" name="btnActivate" id="btnActivate">ACTIVATE SERVICE</button>
                            </div>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script>
$(function() {
    loadDataTable();

    $("#frmUpdate").submit(function(){
        $.ajax({
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            url: "routes.php",
            beforeSend : function(){
               $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "servicedetails.php?sid=" + $("#bid").val();
            }
        });
        return false;
    });

    $("#btnDeactivate").click(function(){
        $.ajax({
            type: "POST",
            data: { sid : $("#sid").val(), sToken : 0  },
            url: "routes.php",
            beforeSend : function(){
               $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "servicedetails.php?sid=" + $("#bid").val();
            }
        });
    });

    function loadDataTable(){
        $.ajax({
            type: "GET",
            url: "routes.php?bid=" + $("#bid").val(),
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblServicesData").empty();
                $("#tblServicesData").append("<tr><td colspan='2'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblServicesData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#tblServicesData").append("<tr><td>" + count + "</td><td>" + value.name + "</td><td>" + value.amount.toFixed(2) + "</td></tr>");
                    });
                }else{
                    $("#tblServicesData").empty();
                }
            }
        }).done(function(){
            var table = $('.serviceDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();
        });
    };
});
</script>
<?php include("include/footer.php") ?>