<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li class="active">SERVICES MANAGEMENT</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="management.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="pull-left">SERVICE MANAGEMENT</h3>
                        <h3 class="pull-right"><a href="newservices.php" class="btn btn-success">New Service</a></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-striped info serviceDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Services Name</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                </tr>    
                            </thead>
                            <tbody id="tblServicesData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/jquery-2.1.1.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    loadDataTable();

    function loadDataTable(){ // Get Services Data
        $.ajax({
            type: "GET",
            url: "routes.php?services=list",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblServicesData").empty();
                $("#tblServicesData").append("<tr><td colspan='5'><div id='loader'></div></td></tr>");
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function (data) {
                var count = 0;
                $("#tblServicesData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        newtype = (value.type == 1) ? "BASIC" : "PACKAGE";
                        newdesc = (value.description.length > 80) ? value.description.substr(0, 100) + "..." : value.description;
                        var sStatus = value.status.split('|');
                        $("#tblServicesData").append("<tr><td><a href='servicedetails.php?sid=" + value.code + "'></a>" + count + "</td><td><span class='label label-" + sStatus[0] + "'>" + sStatus[1] + "</span></td><td>" + newtype + "</td><td>" + value.name + "</td><td>" + newdesc + "</td><td>" + "PHP" + value.amount.toFixed(2) + "</td></tr>");
                    });
                    $('#tblServicesData tr').css('cursor','pointer');
                }else{
                    $("#tblServicesData").empty();
                }
                $(".loading").css("display" , "none");
            }
        }).done(function(){
            var table = $('.serviceDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();

            $('#tblServicesData tr').on("click",function() {
                var href = $(this).find("a").attr("href");
                if(href) {
                    $(location).attr("href",href);
                }
            });
        });
    };
});
</script>
<?php include("include/footer.php") ?>