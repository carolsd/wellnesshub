<?php include("include/header.php"); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li class="active">SETTINGS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="home.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <h3 class="pull-left">Settings</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <a href="changepassword.php" >
                    <div class="custom-button well well-sm">
                        <div class="icon">
                             <i class="fa fa-lock"></i>
                        </div>
                        <div class="options">
                            <h4>Change Password</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
<?php include("include/footer.php") ?>