<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li class="active">SMS MANAGEMENT</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="management.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">SMS MANAGEMENT</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                           <form name="frmSmsGateway" id="frmSmsGateway" method="POST" autocomplete="off">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Device No</label>
                                    <div class="col-lg-8">
                                        <input type="text" placeholder="Device Number" class="form-control text-caps" name="txtDeviceNumber" id="txtDeviceNumber">
                                        <span class="help-block m-b-none text-danger lblDeviceNumber_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Email</label>
                                    <div class="col-lg-8">
                                        <input type="email" placeholder="Email" class="form-control" name="txtEmail" id="txtEmail">
                                        <span class="help-block m-b-none text-danger lblEmail_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Password" class="form-control" name="txtPassword" id="txtPassword">
                                        <span class="help-block m-b-none text-danger lblPassword_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-4 col-lg-8">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <h4>Instruction</h4>
                <ol>
                    <li>Regiter to <a href="https://smsgateway.me/">SMS Gateway</a></li>
                    <li>Download the SMS Gateway app to your android smart phone</li>
                    <li>Key in your device number and account credentials that you have been using for SMS Gateway Account here.</li>
                </ol>
            </div>
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-striped info smsAccountDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Device Number</th>
                                    <th>Email</th>
                                </tr>    
                            </thead>
                            <tbody id="tblSmsAccountData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/jquery.min.js"></script>
<script src="../theme/js/bootstrap.min.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputNum($("#txtDeviceNumber"));
    // inputNum($("#txtAmount"));
    loadDataTable();

    $("#frmSmsGateway").submit(function(){
        if(passwordValidate() & emailValidate() & deviceNumberValidate()){
            $.ajax({
                type: "POST",
                data: { txtDeviceNumber : $("#txtDeviceNumber").val(), txtEmail : $("#txtEmail").val(), txtPassword : $("#txtPassword").val(), regSms : true },
                url: "routes.php",
                beforeSend : function(){
                   $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "smsmanagement.php";
                }
            });
        }
        return false;
    });

    function deviceNumberValidate(){
        if($("#txtDeviceNumber").val() == ""){
            $("#txtDeviceNumber").css(errStyle);
            $(".lblDeviceNumber_Note").text("Please type device number provided by sms gateway");
            $("#txtDeviceNumber").focus();
        }else{
            $("#txtDeviceNumber").css(resStyle);
            $("#txtDeviceNumber").text("");
            $(".lblDeviceNumber_Note").text("");
            return true;
        }
    }

    function emailValidate(){
        if($("#txtEmail").val() == ""){
            $("#txtEmail").css(errStyle);
            $(".lblEmail_Note").text("Please type email registered in sms gateway");
            $("#txtEmail").focus();
        }else{
            $("#txtEmail").css(resStyle);
            $("#txtEmail").text("");
            $(".lblEmail_Note").text("");
            return true;
        }
    }

    function passwordValidate(){
        if($("#txtPassword").val() == ""){
            $("#txtPassword").css(errStyle);
            $(".lblPassword_Note").text("Please type password used in sms gateway");
            $("#txtPassword").focus();
        }else{
            $("#txtPassword").css(resStyle);
            $("#txtPassword").text("");
            $(".lblPassword_Note").text("");
            return true;
        }
    }

    function loadDataTable(){ // Get Services Data
        $.ajax({
            type: "GET",
            url: "routes.php?sms=list",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblSmsAccountData").empty();
                $("#tblSmsAccountData").append("<tr><td colspan='4'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblSmsAccountData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#tblSmsAccountData").append("<tr><td>" + count + "</td><td>" + value.device + "</td><td>" + value.email + "</td></tr>");
                    });
                }else{
                    $("#tblSmsAccountData").empty();
                }
            }
        }).done(function(){
            var table = $('.smsAccountDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();
        });
    };
});
</script>
<?php include("include/footer.php") ?>