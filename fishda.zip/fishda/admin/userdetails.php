<?php
    include("include/header.php");
    $admin = new Administrator();
    $aData = $admin->getAdministratorDetails($_GET['staff']);
    if($aData == 0){
        header("Location:usermanagement.php");
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li><a href="usermanagement.php">USER MANAGEMENT</a></li>
                <li class="active">USER DETAILS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="usermanagement.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <input type="hidden" name="aid" id="aid" value="<?php echo $aData['code']; ?>"/>
                        <h3 class="box-title">ACCOUNT DETAILS</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Employee Name: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo $aData['name_of_employee']; ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <p class="col-lg-4 col-md-4 col-xs-4"><b>Role: </b></p>
                            <div class="col-lg-8 col-md-8 col-xs-8">
                                <p><?php echo ($aData['role'] == 1) ? "ADMIN" : "STAFF"; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($_SESSION['arole'] == 1){ ?>
                <div class="box-footer">
                    <?php if($aData['status'] == 1){ ?>
                        <button class="btn btn-warning btn-block" type="submit" name="btnDeactivate" id="btnDeactivate">DEACTIVATE ACCOUNT</button>
                    <?php }else{ ?>
                        <button class="btn btn-success btn-block" type="submit" name="btnActivate" id="btnActivate">ACTIVATE ACCOUNT</button>
                    <?php } ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h4 class="box-title">SERVICES LIST</h4>
                        <?php if($_SESSION['arole'] == 1){ ?>
                            <button class="btn btn-success" type="submit" name="btnNewService" id="btnNewService">ADD SERVICE</button>
                        <?php } ?>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped info serviceDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Services</th>
                                </tr>    
                            </thead>
                            <tbody id="tblServicesData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h4 class="box-title">SCHEDULE</h4>
                        <?php if($_SESSION['arole'] == 1){ ?>
                            <button class="btn btn-success" type="submit" name="btnNewSchedule" id="btnNewSchedule">ADD SCHEDULE</button>
                        <?php } ?>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped info scheduleDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Day</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                </tr>    
                            </thead>
                            <tbody id="tblScheduleData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="modalAddService" class="modal fade" role="dialog" tabindex='-1'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" id="serviceName">Services</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <span class="text-danger lblchkBasicPackage_Note"></span>
                        <div class="form-group">
                            <ul id="serviceBasicData" class="nav nav-pills nav-stacked">
                                <?php 
                                    require("lib/Services.php");
                                    $services = new Services();
                                    $basic = json_decode($services->getServices(1),true);
                                    foreach ($basic as $basicData) {
                                        echo "<li><label class='control-label'><input type='checkbox' name='chkServices' id='chkServices' value='" . $basicData['code'] . "'/> " . $basicData['name'] . "</label></li>";
                                    }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" name="btnConfirmService" id="btnConfirmService">Confirm</button>
            </div>
        </div>
    </div>
</div>
<div id="modalAddSchedule" class="modal fade" role="dialog" tabindex='-1'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" id="serviceName">SCHEDULE</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="control-label">Day *</label>
                            <select class="form-control" name="txtDay" id="txtDay">
                                <option value="">- SELECT DAY -</option>
                                <option value="MONDAY">MONDAY</option>
                                <option value="TUESDAY">TUESDAY</option>
                                <option value="WEDNESDAY">WEDNESDAY</option>
                                <option value="THURSDAY">THURSDAY</option>
                                <option value="FRIDAY">FRIDAY</option>
                                <option value="SATURDAY">SATURDAY</option>
                                <option value="SUNDAY">SUNDAY</option>
                            </select>
                            <span class="text-danger lblDay_Note"></span>
                        </div>
                        <div class="form-group date">
                            <label class="control-label">Start Time *</label>
                            <div class='input-group date' id='timeStartPicker'>
                                <input type='text' class="form-control" id="txtStartTime" name="txtStartTime"/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-time"></span>
                                </span>
                            </div>
                            <span class="note-block text-danger lblStartTime_Note"></span>
                        </div>
                        <div class="form-group date">
                            <label class="control-label">End Time *</label>
                            <div class='input-group date' id='timeEndPicker'>
                                <input type='text' class="form-control" id="txtEndTime" name="txtEndTime"/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-time"></span>
                                </span>
                            </div>
                            <span class="note-block text-danger lblEndTime_Note"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" type="button" name="btnConfirmSchedule" id="btnConfirmSchedule">Confirm</button>
            </div>
        </div>
    </div>
</div>
<link href="../theme/css/bootstrap-datetimepicker-standalone.css" rel="stylesheet"/>
<script src="../theme/js/moment.js"></script>
<script src="../theme/js/bootstrap-datetimepicker.min.js"></script>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputDisable($("#txtStartTime"));
    inputDisable($("#txtEndTime"));
    $('li label').css('cursor','pointer');
    loadServicesData();
    loadDataTable();

    $('#timeStartPicker').datetimepicker({
        enabledHours: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22],
        format: 'LT'
    });

    $('#timeEndPicker').datetimepicker({
        enabledHours: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22],
        format: 'LT'
    });

    $("#btnDeactivate").click(function(){
        $.ajax({
            type: "GET",
            data: { aid : $("#aid").val(), atoken : 0 },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "userdetails.php?staff=" + $("#aid").val();
            }
        });
    });

    $("#btnActivate").click(function(){
        $.ajax({
            type: "GET",
            data: { aid : $("#aid").val(), atoken : 1 },
            url: "routes.php",
            beforeSend : function(){
                $("body").append("<div class='loading'>Loading&#8230;</div>");
            },
            success: function() {
                window.location.href = "userdetails.php?staff=" + $("#aid").val();
            }
        });
    });

    $("#btnNewService").click(function(){
        $("#modalAddService").modal('show');
    });

    $("#btnConfirmService").click(function(){
        if(servicesValidate()){
            var chkServicesVal = $( "#chkServices:checked" ).map(function() {
                return $( this ).val();
            }).get().join( "|" );
            $.ajax({
                type: "GET",
                data: { aid : $("#aid").val(), chkServicesVal : chkServicesVal,  aServices : true },
                url: "routes.php",
                beforeSend : function(){
                    $("#btnConfirmService").attr('disabled',true);
                    $("#modalAddService").modal('hide');
                    $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    // loadServicesData();
                    window.location.href = "userdetails.php?staff=" + $("#aid").val();
                }
            });
        }else{
            return false;
        }
    });
    
    $("#btnNewSchedule").click(function(){
        $("#modalAddSchedule").modal('show');
    });

    $("#btnConfirmSchedule").click(function(){
        if(endtimeValidate() & starttimeValidate() & dayValidate()){
            $.ajax({
                type: "GET",
                data: { aid : $("#aid").val(), day : $("#txtDay").val(), starttime : $("#txtStartTime").val(), endtime : $("#txtEndTime").val(), aSchedule : true },
                url: "routes.php",
                beforeSend : function(){
                    $("#btnConfirmSchedule").attr('disabled',true);
                    $("#modalAddSchedule").modal('hide');
                    $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    // loadScheduleData();
                    window.location.href = "userdetails.php?staff=" + $("#aid").val();
                }
            });
        }else{
            return false;
        }
    });


    function loadDataTable(){
        $.ajax({
            type: "GET",
            url: "routes.php?aid=" + $("#aid").val() + "&data=schedule",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblScheduleData").empty();
                $("#tblScheduleData").append("<tr><td colspan='4'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblScheduleData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#tblScheduleData").append("<tr><td>" + count + "</td><td>" + value.day + "</td><td>" + value.starttime + "</td><td>" + value.endtime + "</td></tr>");
                    });
                }else{
                    $("#tblScheduleData").empty();
                }
            }
        }).done(function(){
            var table = $('.scheduleDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();
        });
    }

    function loadServicesData(){
        $.ajax({
            type: "GET",
            url: "routes.php?aid=" + $("#aid").val() + "&data=services",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblServicesData").empty();
                $("#tblServicesData").append("<tr><td colspan='2'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblServicesData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#tblServicesData").append("<tr><td>" + count + "</td><td>" + value.name + "</td></tr>");
                    });
                }else{
                    $("#tblServicesData").empty();
                }
            }
        }).done(function(){
            var table = $('.serviceDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();
        });
    };

    function servicesValidate(){
        if(!validateChkServices()){
            $(".lblchkBasicPackage_Note").text("Please select Basic Spa Treatment to complete the reservation.");
        }else{
            $(".lblchkBasicPackage_Note").text("");
            return true;
        }
    } 
    
    function validateChkServices(){
        var isValid = false;
        var allRows = $("input[type='checkbox']");
        for (var i=0; i < allRows.length; i++) {
            if (allRows[i].type == 'checkbox' && allRows[i].name == 'chkServices') {
                if (allRows[i].checked == true) {
                       return true;
                }
            }
        }
        return isValid;
    }

    function dayValidate(){
        if($("#txtDay").val() == ""){
            $("#txtDay").css(errStyle);
            $(".lblDay_Note").text("Please select day");
            $("#txtDay").focus();
        }else{
            $("#txtDay").css(resStyle);
            $(".lblDay_Note").text("");
            return true;
        }
    }

    function starttimeValidate(){
        if($("#txtStartTime").val() == ""){
            $("#txtStartTime").css(errStyle);
            $(".lblStartTime_Note").text("Please select start time");
            $("#txtStartTime").focus();
        }else{
            $("#txtStartTime").css(resStyle);
            $(".lblStartTime_Note").text("");
            return true;
        }
    }

    function endtimeValidate(){
        if($("#txtEndTime").val() == ""){
            $("#txtEndTime").css(errStyle);
            $(".lblEndTime_Note").text("Please select end time");
            $("#txtEndTime").focus();
        }else{
            $("#txtEndTime").css(resStyle);
            $(".lblEndTime_Note").text("");
            return true;
        }
    }
});
</script>
<?php include("include/footer.php") ?>