<?php
    include("include/header.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li class="active">USER MANAGEMENT</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="management.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">USER MANAGEMENT</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                            <form name="frmUser" id="frmUser" method="POST" autocomplete="off">
                                <input type="hidden" name="txtRole" id="txtRole" value="<?php echo $_SESSION['arole']; ?>" />
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Employee's Name</label>
                                    <div class="col-lg-8">
                                        <input type="text" placeholder="Employee's Complete Name" class="form-control text-caps" name="txtEmployeeName" id="txtEmployeeName">
                                        <span class="help-block text-danger lblEmployeeName_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Username</label>
                                    <div class="col-lg-8">
                                        <input type="text" placeholder="Username" class="form-control" name="txtUsername" id="txtUsername">
                                        <span class="help-block text-danger lblUsername_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Password" class="form-control" name="txtPassword" id="txtPassword">
                                        <span class="help-block text-danger lblPassword_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Confirm Password</label>
                                    <div class="col-lg-8">
                                        <input type="password" placeholder="Confirm Password" class="form-control" name="txtConfirmPassword" id="txtConfirmPassword">
                                        <span class="help-block text-danger lblConfirmPassword_Note"></span>
                                    </div>
                                </div>
                                <?php if($_SESSION['arole'] == '1'){ ?>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Role</label>
                                    <div class="col-lg-8">
                                        <select class="form-control" name="cboRole" id="cboRole">
                                            <option value="">- SELECT ROLE -</option>
                                            <option value="1">ADMIN</option>
                                            <option value="2">STAFF</option>
                                        </select>
                                        <span class="help-block text-danger lblRole_Note"></span>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="form-group">
                                    <div class="col-lg-offset-4 col-lg-8">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-striped info accountDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Employee's Name</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                </tr>    
                            </thead>
                            <tbody id="tblAccountData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputText($("#txtEmployeeName"));
    loadDataTable();

    $("#frmUser").submit(function(){
        if(roleValidate() & passwordValidate() & usernameValidate() & employeeNameValidate()){
            $.ajax({
                type: "POST",
                data: { txtEmployeeName : $("#txtEmployeeName").val(), txtUsername : $("#txtUsername").val(), txtPassword : $("#txtPassword").val(), cboRole : $("#cboRole").val(), regUser : true },
                url: "routes.php",
                beforeSend : function(){
                   $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "usermanagement.php";
                }
            });
        }
        return false;
    });

    function loadDataTable(){
        $.ajax({
            type: "GET",
            url: "routes.php?account=list&role=" + $("#txtRole").val(),
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblAccountData").empty();
                $("#tblAccountData").append("<tr><td colspan='4'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblAccountData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        if(value.role == 1) arole = "ADMIN"; else arole = "STAFF";
                        if(value.status == 1) isactive = "<span class='label label-success'>ACTIVE</span>"; else isactive = "<span class='label label-warning'>DEACTIVATED</span>";
                        $("#tblAccountData").append("<tr><td><a href='userdetails.php?staff=" + value.code + "'>" + count + "</a></td><td>" + value.name_of_employee + "</td><td>" + value.username + "</td><td>" + arole + "</td><td>"+ isactive +"</td></tr>");
                    });
                    $('#tblAccountData tr').css('cursor','pointer');
                }else{
                    $("#tblAccountData").empty();
                }
            }
        }).done(function(){
            var table = $('.accountDataTables').DataTable({
                "paging": false,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": false,
                "autoWidth": false
            });

            table.destroy();
            table.draw();

            $('#tblAccountData tr').on("click",function() {
                var href = $(this).find("a").attr("href");
                if(href) {
                    $(location).attr("href",href);
                }
            });
        });
    }

    function employeeNameValidate(){
        if($("#txtEmployeeName").val() == ""){
            $("#txtEmployeeName").css(errStyle);
            $(".lblEmployeeName_Note").text("Please type employee's complete name");
            $("#txtEmployeeName").focus();
        }else if($("#txtEmployeeName").val() != ""){
            if($("#txtEmployeeName").val().length >= 8){
                $("#txtEmployeeName").css(resStyle);
                $("#txtEmployeeName").text("");
                $(".lblEmployeeName_Note").text("");
                return true;
            }else{
                $("#txtEmployeeName").css(errStyle);
                $(".lblEmployeeName_Note").text("Employee's Name must be minimum 8 characters length");
                $("#txtEmployeeName").focus();
            }
        }else{
            $("#txtEmployeeName").css(resStyle);
            $("#txtEmployeeName").text("");
            $(".lblEmployeeName_Note").text("");
            return true;
        }
    }

    function usernameValidate(){
        if($("#txtUsername").val() == ""){
            $("#txtUsername").css(errStyle);
            $(".lblUsername_Note").text("Please type username");
            $("#txtUsername").focus();
        }else if($("#txtUsername").val() != ""){
            if($("#txtUsername").val().length >= 8){
                if(usernameCheck() == '0'){
                    $("#txtUsername").css(resStyle);
                    $("#txtUsername").text("");
                    $(".lblUsername_Note").text("");
                    return true;
                }else{
                    $("#txtUsername").css(errStyle);
                    $(".lblUsername_Note").text("The username that you enter is already exist");
                    $("#txtPassword").focus();
                }
            }else{
                $("#txtUsername").css(errStyle);
                $(".lblUsername_Note").text("Username must be minimum 8 characters length");
                $("#txtUsername").focus();
            }
        }else{
            $("#txtUsername").css(resStyle);
            $("#txtUsername").text("");
            $(".lblUsername_Note").text("");
            return true;
        }
    }

    function passwordValidate(){
        if($("#txtPassword").val() == ""){
            $("#txtPassword").css(errStyle);
            $(".lblPassword_Note").text("Please type New Password");
            $("#txtPassword").focus();
        }else if($("#txtPassword").val() != ""){
            if($("#txtPassword").val().length >= 8){
                $("#txtPassword").css(resStyle);
                $(".lblPassword_Note").text("");
                if(confirm_passwordValidate()){
                    return true;
                }else{
                    return false;
                }
            }else{
                $("#txtPassword").css(errStyle);
                $(".lblPassword_Note").text("Password must be minimum 8 characters length");
                $("#txtPassword").focus();
            }
        }else{
            $("#txtPassword").css(resStyle);
            $(".lblPassword_Note").text("");
            return true;
        }
    }
    
    function confirm_passwordValidate(){
        if($("#txtPassword").val() == $("#txtConfirmPassword").val() && $("#txtPassword").val().length >= 8){
            $("#txtConfirmPassword").css(resStyle);
            $(".lblConfirmPassword_Note").text("");
            return true;
        }else{
            $("#txtConfirmPassword").css(errStyle);
            $(".lblConfirmPassword_Note").text("New Password not match");
        }
    }

    function roleValidate(){
        // if($("#txtRole").val() == "2"){
        //     return true;
        // }else{
            if($("#cboRole").val() == ""){
                $("#cboRole").css(errStyle);
                $(".lblRole_Note").text("Please select Role");
                $("#cboRole").focus();
            }else{
                $("#cboRole").css(resStyle);
                $(".lblRole_Note").text("");
                return true;
            }
        // }
    }

    function usernameCheck(){
        var uname;
        $.ajax({
            type: "POST",
            url: "routes.php",
            data: { txtUsername : $("#txtUsername").val(), nUsername : true },
            async: false,
            success: function(result){
                uname = result;
            }
        });
        return uname;
    }
});
</script>
<?php include("include/footer.php") ?>