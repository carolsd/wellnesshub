<?php
    include("include/header.php");
    require("lib/Util.php");
        if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
    $util = new Util();
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="reports.php">REPORTS</a></li>
                <li class="active">WEB VISITOR REPORTS</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="reports.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <h3 class="pull-left">Web Visitors Report</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="control-label">Date From</label>
                    <table width="100%">
                        <tr>
                            <td>
                                <select class="form-control" name="cboMonthFrom" id="cboMonthFrom">
                                    <option value="">- MM -</option>
                                    <option value="1">JANUARY</option>
                                    <option value="2">FEBRUARY</option>
                                    <option value="3">MARCH</option>
                                    <option value="4">APRIL</option>
                                    <option value="5">MAY</option>
                                    <option value="6">JUNE</option>
                                    <option value="7">JULY</option>
                                    <option value="8">AUGUST</option>
                                    <option value="9">SEPTEMBER</option>
                                    <option value="10">OCTOBER</option>
                                    <option value="11">NOVEMBER</option>
                                    <option value="12">DECEMBER</option>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="cboDayFrom" id="cboDayFrom">
                                    <option value="">- DD -</option>
                                    <?php
                                        for($day=1; $day!=32; $day++){
                                            echo "<option value='".$day."'>".$day."</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="cboYearFrom" id="cboYearFrom">
                                    <option value="">- YYYY -</option>
                                    <?php
                                        foreach ($util->getFromYear() as $key => $value) {
                                            echo "<option value='".$value['yearFrom']."'>".$value['yearFrom']."</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <span class="help-block m-b-none text-danger lblDateFrom_Note"></span>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <label class="control-label">Date To</label>
                    <table width="100%">
                        <tr>
                            <td>
                                <select class="form-control" name="cboMonthTo" id="cboMonthTo">
                                    <option value="">- MONTH -</option>
                                    <option value="1">JANUARY</option>
                                    <option value="2">FEBRUARY</option>
                                    <option value="3">MARCH</option>
                                    <option value="4">APRIL</option>
                                    <option value="5">MAY</option>
                                    <option value="6">JUNE</option>
                                    <option value="7">JULY</option>
                                    <option value="8">AUGUST</option>
                                    <option value="9">SEPTEMBER</option>
                                    <option value="10">OCTOBER</option>
                                    <option value="11">NOVEMBER</option>
                                    <option value="12">DECEMBER</option>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="cboDayTo" id="cboDayTo">
                                    <option value="">- DD -</option>
                                    <?php
                                        for($day=1; $day!=32; $day++){
                                            echo "<option value='".$day."'>".$day."</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select class="form-control" name="cboYearTo" id="cboYearTo">
                                    <option value="">- YYYY -</option>
                                    <?php
                                        foreach ($util->getToYear() as $key => $value) {
                                            echo "<option value='".$value['yearTo']."'>".$value['yearTo']."</option>";
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <span class="help-block m-b-none text-danger lblDateTo_Note"></span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="form-groups">
                    <button type="button" class="btn btn-primary" name="btnGenerate" id="btnGenerate">Generate</button>
                    <button type="button" class="btn btn-success" name="btnExport" id="btnExport">Export</button>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table table-striped table-hover webVisitDataTables">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>IP Address</th>
                                <th>Browser Details</th>
                                <th>Date</th>
                                <th>Count</th>
                            </tr>
                        </thead>
                        <tbody id="tblWebVisitData">

                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">
                                    <ul class="pagination pull-right"></ul>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    var d = new Date();
    setTimeout(function(){selectDefault();},800);
    $("#btnGenerate").click(function(){
        loadDataTable();
    });

    $("#btnExport").click(function(){
        if($("#cboDayFrom").val().length==1){ 
            from_d="0"+$("#cboDayFrom").val();
        }else{
            from_d=$("#cboDayFrom").val();
        }
        if($("#cboMonthFrom").val().length==1){ 
            from_m="0"+$("#cboMonthFrom").val();
        }else{
            from_m=$("#cboMonthFrom").val();
        }
        if($("#cboDayTo").val().length==1){ 
            to_d="0"+$("#cboDayTo").val();
        }else{
            to_d=$("#cboDayTo").val();
        }
        if($("#cboMonthTo").val().length==1){ 
            to_m="0"+$("#cboMonthTo").val();
        }else{
            to_m=$("#cboMonthTo").val();
        }
        
        var dateFrom = $("#cboYearFrom").val()+"-"+from_m+"-"+from_d;
        var dateTo = $("#cboYearTo").val()+"-"+to_m+"-"+to_d;

        if(dateFromValidate() & dateToValidate()){
            window.location.href = "routes.php?webvisit=export&dateFrom=" + dateFrom + "&dateTo=" + dateTo;
        }else{
            return false;
        }
    });

    function loadDataTable(){ // Get Reservation Report Generated Data
        if($("#cboDayFrom").val().length==1){ 
            from_d="0"+$("#cboDayFrom").val();
        }else{
            from_d=$("#cboDayFrom").val();
        }
        if($("#cboMonthFrom").val().length==1){ 
            from_m="0"+$("#cboMonthFrom").val();
        }else{
            from_m=$("#cboMonthFrom").val();
        }
        if($("#cboDayTo").val().length==1){ 
            to_d="0"+$("#cboDayTo").val();
        }else{
            to_d=$("#cboDayTo").val();
        }
        if($("#cboMonthTo").val().length==1){ 
            to_m="0"+$("#cboMonthTo").val();
        }else{
            to_m=$("#cboMonthTo").val();
        }
        
        var dateFrom = $("#cboYearFrom").val()+"-"+from_m+"-"+from_d;
        var dateTo = $("#cboYearTo").val()+"-"+to_m+"-"+to_d;

        if(dateFromValidate() & dateToValidate()){
            $.ajax({
                type: "GET",
                url: "routes.php?webvisit=report&dateFrom=" + dateFrom + "&dateTo=" + dateTo,
                dataType: "json",
                asyc: true,
                beforeSend: function () {
                    $("#tblWebVisitData").empty();
                    $("#tblWebVisitData").append("<tr><td colspan='5'><div id='loader'></div></td></tr>");
                    $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function (data) {
                    var count = 0;
                    $("#tblWebVisitData").empty();
                    if(Object.keys(data).length > 0){
                        $.each(data, function (key, value) {
                            count++;
                            $("#tblWebVisitData").append("<tr><td>" + count + "</td><td>" + value.code + "</td><td>" + value.log + "</td><td>" + value.date_created + "</td><td>" + value.count + "</td></tr>");
                        });
                    }else{
                        $("#tblWebVisitData").empty();
                    }
                    $(".loading").css("display" , "none");
                }
            }).done(function(){
                var table = $('.webVisitDataTables').DataTable({
                    "paging": false,
                    "lengthChange": false,
                    "searching": false,
                    "ordering": false,
                    "info": false,
                    "autoWidth": false
                });

                table.destroy();
                table.draw();
            });
        }else{
            return false;
        }
    }

    function dateFromValidate(){
        if(fromYearValidate() & fromMonthValidate() & fromDayValidate()){
            return true;
        }else{
            return false;
        }
    }
    
    function fromDayValidate(){
        if($("#cboDayFrom").val() == ""){
            $("#cboDayFrom").css(errStyle);
            $(".lblDateFrom_Note").text("Please complete Date From");
            $("#cboDayFrom").focus();
        }else{
            $("#cboDayFrom").css(resStyle);
            $(".lblDateFrom_Note").text("");
            return true;
        }
    }
    
    function fromMonthValidate(){
        if($("#cboMonthFrom").val() == ""){
            $("#cboMonthFrom").css(errStyle);
            $(".lblDateFrom_Note").text("Please complete Date From");
            $("#cboMonthFrom").focus();
        }else{
            $("#cboMonthFrom").css(resStyle);
            $(".lblDateFrom_Note").text("");
            return true;
        }
    }
    
    function fromYearValidate(){
        if($("#cboYearFrom").val() == ""){
            $("#cboYearFrom").css(errStyle);
            $(".lblDateFrom_Note").text("Please complete Date From");
            $("#cboYearFrom").focus();
        }else{
            $("#cboYearFrom").css(resStyle);
            $(".lblDateFrom_Note").text("");
            return true;
        }
    }

    function dateToValidate(){
        if(toYearValidate() & toMonthValidate() & toDayValidate()){
            return true;
        }else{
            return false;
        }
    }
    
    function toDayValidate(){
        if($("#cboDayTo").val() == ""){
            $("#cboDayTo").css(errStyle);
            $(".lblDateTo_Note").text("Please complete Date To");
            $("#cboDayTo").focus();
        }else{
            $("#cboDayTo").css(resStyle);
            $(".lblDateTo_Note").text("");
            return true;
        }
    }
    
    function toMonthValidate(){
        if($("#cboMonthTo").val() == ""){
            $("#cboMonthTo").css(errStyle);
            $(".lblDateTo_Note").text("Please complete Date From");
            $("#cboMonthTo").focus();
        }else{
            $("#cboMonthTo").css(resStyle);
            $(".lblDateTo_Note").text("");
            return true;
        }
    }
    
    function toYearValidate(){
        if($("#cboYearTo").val() == ""){
            $("#cboYearTo").css(errStyle);
            $(".lblDateTo_Note").text("Please complete Date From");
            $("#cboYearTo").focus();
        }else{
            $("#cboYearTo").css(resStyle);
            $(".lblDateTo_Note").text("");
            return true;
        }
    }

    function selectDefault(){
        $('#cboMonthFrom').val(d.getMonth()+1);
        $('#cboDayFrom').val(d.getDate());
        $('#cboYearFrom').val(d.getFullYear());
        $('#cboMonthTo').val(d.getMonth()+1);
        $('#cboDayTo').val(d.getDate());
        $('#cboYearTo').val(d.getFullYear());
    }
});
</script>
<?php include("include/footer.php") ?>