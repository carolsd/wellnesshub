<?php
    include("include/header.php");
    if($_SESSION['arole'] == '2'){
        header("Location:userdetails.php?staff=".$_SESSION['acode']);
    }
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ul class="breadcrumb">
                <li><a href="home.php">DASHBOARD</a></li>
                <li><a href="management.php">MANAGEMENT</a></li>
                <li class="active">ABOUT FISHDA MANAGEMENT</li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <a href="management.php" class="btn btn-success"><i class="fa fa-arrow-left"></i> BACK</a>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">ABOUT FISHDA MANAGEMENT</b></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="row">
                           <form name="frmAboutFishda" id="frmAboutFishda" method="POST" autocomplete="off">
                                <div class="form-group">
                                    <label class="col-lg-2 control-label">Title*</label>
                                    <div class="col-lg-10">
                                        <input type="text" placeholder="About Fishda Title" class="form-control" name="txtTitle" id="txtTitle">
                                        <span class="help-block m-b-none text-danger lblDeviceNumber_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-2 control-label">Content*</label>
                                    <div class="col-lg-10">
                                        <textarea class="form-control" placeholder="About Fishda Content" rows="6" name="txtContent" id="txtContent"></textarea>
                                        <span class="help-block m-b-none text-danger lblContent_Note"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-body">
                        <table class="table table-striped info aboutDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                </tr>    
                            </thead>
                            <tbody id="tblAboutData">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<link href="../theme/css/bootstrap-wysihtml5.css" rel="stylesheet"/>
<script src="../theme/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="../theme/js/fishda.js"></script>
<script src="../theme/js/wysihtml5-0.3.0.js"></script>
<script src="../theme/js/bootstrap-wysihtml5.js"></script>
<script>
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    loadDataTable();
    $('#txtContent').wysihtml5();

    $("#frmAboutFishda").submit(function(){
        if(contentValidate() & titleValidate()){
            $.ajax({
                type: "POST",
                data: { txtTitle : $("#txtTitle").val(), txtContent : $("#txtContent").val(), regAbout : true },
                url: "routes.php",
                beforeSend : function(){
                   $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "webmanagement.php";
                }
            });
        }
        return false;
    });

    function titleValidate(){
        if($("#txtTitle").val() == ""){
            $("#txtTitle").css(errStyle);
            $(".lblTitle_Note").text("Please type title");
            $("#txtTitle").focus();
        }else{
            $("#txtTitle").css(resStyle);
            $("#txtTitle").text("");
            $(".lblTitle_Note").text("");
            return true;
        }
    }

    function contentValidate(){
        if($("#txtContent").val() == ""){
            $("#txtContent").css(errStyle);
            $(".lblContent_Note").text("Please type content");
            $("#txtContent").focus();
        }else{
            $("#txtContent").css(resStyle);
            $("#txtContent").text("");
            $(".lblContent_Note").text("");
            return true;
        }
    }

    function loadDataTable(){ // Get Services Data
        $.ajax({
            type: "GET",
            url: "routes.php?about=list",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#tblAboutData").empty();
                $("#tblAboutData").append("<tr><td colspan='4'><div id='loader'></div></td></tr>");
            },
            success: function (data) {
                var count = 0;
                $("#tblAboutData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        // content = (value.content.length > 80) ? value.content.substr(0, 100) + "..." : value.content;
                        $("#tblAboutData").append("<tr><td>" + count + "</td><td><span id='title'>" + value.title + "</span></td><td><span id='content'>" + value.content + "</span></td></tr>");
                    });
                }else{
                    $("#tblAboutData").empty();
                }
            }
        });
    };
});
</script>
<?php include("include/footer.php") ?>