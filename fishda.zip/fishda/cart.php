<?php
    session_start();
	include("visit.php");
	visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">
    <link href="theme/css/font-awesome.min.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
            <h3 class="text-center text-danger" id="clockbox"></h3>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li><a href="index.php">Services</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
                    <li class="active"><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="article-content">
    	            <div class="table-responsive">
                        <table class="table table-striped table-hover reservationDataTables">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th class="col-lg-2">Name</th>
                                    <th class="col-lg-6">Description</th>
                                    <th class="col-lg-2">Price</th>
                                    <th class="col-lg-2">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="tblReservationData">
                                <?php
                                    $item_total = 0;
                                    if(isset($_SESSION['cart_item'])){
                                        $count = 0;
                                        foreach ($_SESSION["cart_item"] as $item){
                                            $count++;
                                ?>
                                    <tr>
                                        <td><?php echo $count; ?></td>
                                        <td><strong><?php echo $item["name"]; ?></strong></td>
                                        <td><?php echo $item["description"]; ?></td>
                                        <td align=right><?php echo "&#8369; ".number_format($item["amount"],2); ?></td>
                                        <td><a href="web.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction"><i class="fa fa-times"></i> Remove</a></td>
                                    </tr>
                                <?php
                                            $item_total += ($item["amount"]);
                                        }
                                    }else{
                                ?>
                                    <tr>
                                        <td colspan="5" class="text-danger text-center">Cart is Empty</td>
                                    </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="5" class="text-right">
                                        <strong>Total:</strong> <?php echo "&#8369; ".number_format($item_total,2); ?>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="text-right">
                        <a href="index.php" class="btn btn-primary" name="btnContinue" id="btnContinue">Continue Selecting</a>
                        <a href="checkout.php" class="btn btn-success" name="btnCheckOut" id="btnCheckOut"<?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "disabled='true'"; ?>>Check Out</a>
                    </div>
                </div>
	        </div>
	    </div>
    </div>
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
                <div class="col-lg-offset-4 col-lg-4 col-lg-offset-4">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="https://www.facebook.com/fishspamassage/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/fishdawellnesshub/" target="_blank"><i class="fa fa-instagram"></i></a></li>

                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
</body>
</html>
<script src="theme/js/jquery-2.1.1.js"></script>
<script src="theme/js/bootstrap.min.js"></script>
<script src="theme/js/jquery.timeago.js"></script>
<script src="theme/js/format.20110630-1100.min.js"></script>
<script type="text/javascript">
$(function(){
	tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

    function GetClock(){
        var d=new Date();
        var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
        if(nyear<1000)
            nyear+=1900;
            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

        if(nhour==0){
            ap=" AM";nhour=12;
        }else if(nhour<12){
            ap=" AM";
        }else if(nhour==12){
            ap=" PM";
        }else if(nhour>12){
            ap=" PM";nhour-=12;
        }

        if(nmin<=9)
            nmin="0"+nmin;
        if(nsec<=9)
            nsec="0"+nsec;

        document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
    }

    window.onload=function(){
        GetClock();
        setInterval(GetClock,1000);
    }

});
</script>