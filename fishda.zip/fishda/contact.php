<?php
    include("visit.php");
    visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">
	<link href="theme/css/font-awesome.min.css" rel="stylesheet">

	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<!-- <link href="Jumbotron%20Template%20for%20Bootstrap_files/ie10-viewport-bug-workaround.css" rel="stylesheet"> -->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
            <h3 class="text-center text-danger" id="clockbox"></h3>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li><a href="index.php">Services</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
					<li class="active"><a href="contact.php">Contact</a></li>
                    <li><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="article-content">
	            	<h2>Contact</h2>
                    <div class="row">
                    	<div class="col-lg-6">
                            <h5><i class="fa fa-mobile"></i> 0942 977 3174</h5>
                            <h5><i class="fa fa-envelope-o"></i> fishdawellnesshub@gmail.com</h5>
                            <h5><i class="fa fa-home"></i> Fishda Wellness Hub, Cubao, Quezon City</h5>
                            <!-- <img src="theme/img/cubao.png" class="img-responsive img-full" /> -->
                            <div id="googleMap" style="width:100%;height:400px;"></div>
                    	</div>
                    	<div class="col-lg-6">
                    		<form name="frmContact" id="frmContact" method="POST" autocomplete="off">
                                <div class="form-group">
                                    <label class="control-label">Name*</label>
                                    <input type="text" class="form-control text-caps" placeholder="Full Name" name="txtFullName" id="txtFullName" maxlength="30">
                                    <span class="text-danger lblFullName_Note"></span>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Email Address (optional)</label>
                                    <input type="email" class="form-control" placeholder="Email" name="txtEmail" id="txtEmail">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Mobile Number*</label>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            +63
                                        </span>
                                        <input type="text" placeholder="Mobile" class="form-control" name="txtMobile" id="txtMobile"/>
                                    </div>
                                    <span class="text-danger lblMobile_Note"></span>
                                </div>
	                            <div class="form-group">
	                                <label class="control-label">Message Type*</label>
	                                <select class="form-control" name="cboType" id="cboType">
                                        <option value="">- SELECT MESSAGE TYPE -</option>
                                        <option value="1">FEEDBACK</option>
                                        <option value="2">INQUIRIES</option>
                                    </select>
	                                <span class="text-danger lblType_Note"></span>
	                            </div>
	                            <div class="form-group">
	                                <label class="control-label">Message*</label>
	                                <textarea class="form-control" placeholder="Type your Message Here..." rows="6" name="txtMessage" id="txtMessage" maxlength="200"></textarea>
	                                <span class="text-danger lblMessage_Note"></span>
	                            </div>
	                            <div class="form-group">
	                                <button type="submit" class="btn btn-primary" name="btnContact" id="btnContact">Submit</button>
	                            </div>
                    		</form>
                    	</div>
                    </div>
	            </div>
	        </div>
	    </div>
    </div>
    
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
                <div class="col-lg-offset-4 col-lg-4 col-lg-offset-4">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="https://www.facebook.com/fishspamassage/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/fishdawellnesshub/" target="_blank"><i class="fa fa-instagram"></i></a></li>  
					</ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
</body>
</html>
<script src="theme/js/jquery-2.1.1.js"></script>
<script src="theme/js/bootstrap.min.js"></script>
<script src="theme/js/jquery.mask.min.js"></script>
<script src="theme/js/fishda.js"></script>
<script type="text/javascript">
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    inputNum($("#txtMobile"));
    inputText($("#txtFullName"));
    $("#txtMobile").mask("999 999 9999", {placeholder: "9-- --- ----"});

    $("#frmContact").submit(function(){
        if(messageValidate() & messageTypeValidate() & mobileValidate() & fullnameValidate()){
            $.ajax({
                type: "POST",
                data: { txtFullName : $("#txtFullName").val(),txtEmail : $("#txtEmail").val(),txtMobile : $("#txtMobile").val(),txtMessage : $("#txtMessage").val(),contData : true },
                url: "sendmail.php",
                beforeSend : function(){
                    $("body").append("<div class='loading'>Loading&#8230;</div>");
                },
                success: function() {
                    window.location.href = "success.php";
                }
            });
        }
        return false;
    });

    function fullnameValidate(){
        if($("#txtFullName").val() == ""){
            $("#txtFullName").css(errStyle);
            $(".lblFullName_Note").text("Please type your Full Name");
            $("#txtFullName").focus();
        }else{
            if($("#txtFullName").val().length > 45){
                $("#txtFullName").css(errStyle);
                $(".lblFullName_Note").text("Full Name must be maximum 30 characters length");
                $("#txtFullName").focus();
            }else{
                $("#txtFullName").css(resStyle);
                $("#txtFullName").text("");
                $(".lblFullName_Note").text("");
                return true;
            }
        }
    }

    function mobileValidate(){
        if($("#txtMobile").val() == ""){
            $("#txtMobile").css(errStyle);
            $(".lblMobile_Note").text("Please type your Mobile Number");
            $("#txtMobile").focus();
        }else{
            if($("#txtMobile").val().slice(0,1) != 9){
                $("#txtMobile").css(errStyle);
                $(".lblMobile_Note").text("Invalid Mobile number format");
                $("#txtMobile").focus();
            }else if($("#txtMobile").val().length < 10){
                $("#txtMobile").css(errStyle);
                $(".lblMobile_Note").text("Mobile number must be 10 characters length");
                $("#txtMobile").focus();
            }else{
                $("#txtMobile").css(resStyle);
                $("#txtMobile").text("");
                $(".lblMobile_Note").text("");
                return true;
            }
        }
    }

    function messageTypeValidate(){
        if($("#cboType").val() == ""){
            $("#cboType").css(errStyle);
            $(".lblType_Note").text("Please select Message Type");
            $("#cboType").focus();
        }else{
            $("#cboType").css(resStyle);
            $("#cboType").text("");
            $(".lblType_Note").text("");
            return true;
        }
    }

    function messageValidate(){
        if($("#txtMessage").val() == ""){
            $("#txtMessage").css(errStyle);
            $(".lblMessage_Note").text("Please type your Message");
            $("#txtMessage").focus();
        }else{
            $("#txtMessage").css(resStyle);
            $("#txtMessage").text("");
            $(".lblMessage_Note").text("");
            return true;
        }
    }

    tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

    function GetClock(){
        var d=new Date();
        var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
        if(nyear<1000)
            nyear+=1900;
            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

        if(nhour==0){
            ap=" AM";nhour=12;
        }else if(nhour<12){
            ap=" AM";
        }else if(nhour==12){
            ap=" PM";
        }else if(nhour>12){
            ap=" PM";nhour-=12;
        }

        if(nmin<=9)
            nmin="0"+nmin;
        if(nsec<=9)
            nsec="0"+nsec;

        document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
    }

    window.onload=function(){
        GetClock();
        setInterval(GetClock,1000);
    }
});
function myMap() {
    var mapProp= {
        center:new google.maps.LatLng(14.6186517,121.0527981), // https://www.google.com.ph/maps/@14.6186517,121.0527981,16z
        zoom:15,
    };
    var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAhSkXJJiy5vjTPnwiXYV9Og8zaUuiG8rM&callback=myMap"></script>