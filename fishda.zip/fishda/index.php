<?php
    session_start();
	include("visit.php");
	visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">
    <link href="theme/css/font-awesome.min.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
            <h3 class="text-center text-danger" id="clockbox"></h3>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li class="active"><a href="index.php">Services</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
					<li><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="box back_box">
	                <div class="text-center">
	                    <div id="carousel-example-generic" class="carousel slide">
	                        <ol class="carousel-indicators hidden-xs">
	                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
	                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
	                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
	                        </ol>
	                        <div class="carousel-inner">
	                            <div class="item active">
	                                <img class="img-responsive img-full" src="theme/img/banner/1.png" alt="">
	                            </div>
	                            <div class="item">
	                                <img class="img-responsive img-full" src="theme/img/banner/2.png" alt="">
	                            </div>
	                            <div class="item">
	                                <img class="img-responsive img-full" src="theme/img/banner/3.png" alt="">
	                            </div>
	                        </div>
	                        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
	                            <span class="icon-prev"></span>
	                        </a>
	                        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
	                            <span class="icon-next"></span>
	                        </a>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
    </div>
    <div class="container">
		<div class="col-lg-12">
			<h3>Basic Services</h3>
    	</div>
		<div id="serviceBasicData">
			
		</div>
    </div>
    <div class="container">
    	<div class="col-lg-12">
			<h3>Package Services</h3>
    	</div>
		<div id="servicePackageData">
			
		</div>
    </div>
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
                <div class="col-lg-offset-4 col-lg-4 col-lg-offset-4">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="https://www.facebook.com/fishspamassage/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/fishdawellnesshub/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
	<div id="modalTestimonial" class="modal fade" role="dialog" tabindex='-1'>
	    <div class="modal-dialog modal-lg">
	        <div class="modal-content">
	            <div class="modal-header">
	                <button type="button" class="close" data-dismiss="modal">&times;</button>
	                <h4 class="modal-title" id="serviceName"></h4>
	            </div>
	            <div class="modal-body">
	                <div class="row">
						<div class="col-lg-6" id="serviceDetails">
								
						</div>
						<div class="col-lg-6">
	                        <div class="panel-body" id="serviceComments">
	                            
	                        </div>
	                        <div class="panel-footer">
	                        	<input type="hidden" name="sId" id="sId">
	                            <div class="input-group">
									<input type="text" class="form-control" placeholder="..." name="txtComment" id="txtComment" maxlength="200">
									<span class="input-group-btn">
										<button class="btn btn-primary" type="button" name="btnComment" id="btnComment">Post</button>
									</span>
								</div>
	                        </div>
						</div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</body>
</html>
<script src="theme/js/jquery-2.1.1.js"></script>
<script src="theme/js/bootstrap.min.js"></script>
<script src="theme/js/jquery.timeago.js"></script>
<script src="theme/js/format.20110630-1100.min.js"></script>
<script type="text/javascript">
$(function(){
	$("#serviceComments").css({'height':'300px', 'overflow' : 'scroll', 'overflow-x' : 'hidden'});
	$("#btnComment").attr('disabled','true');
	serviceBasicData();
    servicePackageData();
	$('.carousel').carousel({
        interval: 5000 //changes the speed
    });
    // $.fn.digits = function(){ 
    //     return this.each(function(){ 
    //         $(this).text( $(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,") ); 
    //     })
    // }

    function serviceBasicData(){ // Get Basic Services Data
        $.ajax({
            type: "GET",
            url: "web.php?type=home&services=basic",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#serviceBasicData").empty();
                $("#serviceBasicData").append("<div class='text-center'><img src='theme/img/spinner.gif'></div>");;
            },
            success: function (data) {
                var count = 0;
                $("#serviceBasicData").empty();
                $("#serviceName").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        newdesc = (value.description.length > 80) ? value.description.substr(0, 100) + "..." : value.description;
                        $("#serviceBasicData").append("<div class='col-md-4'><div class='box'><div class='box-content service-box'><div class='service-imitation'><img src='theme/img/services/" + value.photo + "' style='height:150px;'/></div><div class='service-desc'><h5 class='text-center'>" + value.name + "</h5><h4 class='text-center'>&#8369; " + format('#,##0.00', value.amount) + "</h4><p class='text-justify'>" + newdesc + "</p></div><div class='service-footer'><a href='web.php?action=add&code=" + value.code + "' class='btn btn-danger btn-block' title='" + value.name + "'><i class='fa fa-cart-plus'></i> Add to Cart</a></div></div></div></div>");
                    });
                    $('#serviceBasicData label').css('cursor','pointer');
                }else{
                    $("#serviceBasicData").empty();
                    $("#serviceBasicData").append("<li>No Service Available for Basic Spa Treatment</li>");
                }
            }
        }).done(function(){
        	testimonialModal();
        });
    }

    function servicePackageData(){ // Get Package Services Data
        $.ajax({
            type: "GET",
            url: "web.php?type=home&services=package",
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#servicePackageData").empty();
                $("#servicePackageData").append("<div class='text-center'><img src='theme/img/spinner.gif'></div>");;
            },
            success: function (data) {
                var count = 0;
                $("#servicePackageData").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        newdesc = (value.description.length > 80) ? value.description.substr(0, 100) + "..." : value.description;
                        $("#servicePackageData").append("<div class='col-md-4'><div class='box'><div class='box-content service-box'><div class='service-imitation'><img src='theme/img/services/" + value.photo + "' style='height:150px;'/></div><div class='service-desc'><h5 class='text-center'>" + value.name + "</h5><h4 class='text-center'>&#8369;" + format('#,##0.00', value.amount) + "</h4><p class='text-justify'>" + newdesc + "</p></div><div class='service-footer'><a href='web.php?action=add&code=" + value.code + "' class='btn btn-danger btn-block' title='" + value.name + "'><i class='fa fa-cart-plus'></i> Add to Cart</a></div></div></div></div>");
                    });
                    $('#servicePackageData label').css('cursor','pointer');
                }else{
                    $("#servicePackageData").empty();
                    $("#servicePackageData").append("<li>No Service Available for Package Spa Treatment</li>");
                }
            }
        }).done(function(){
        	testimonialModal();
        });
    }

    function testimonialModal(){
    	$(".btnModal").click(function(e){
    		e.preventDefault();
    		$("#modalTestimonial").modal("show");
            var code = $(this).attr("href");
            var title = $(this).attr("title");
            $("#sId").val(code);
            $("#serviceName").empty();
            $("#serviceName").append(title);
    		getServiceDescription(code);
    		getServiceComments(code);
    	});
    }

    function getServiceDescription(code){
    	$.ajax({
            type: "GET",
            url: "web.php?service=details&code=" + code,
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#serviceDetails").empty();
                $("#serviceDetails").append("<div class='text-center'><img src='theme/img/spinner.gif'></div>");;
            },
            success: function (data) {
                var count = 0;
                $("#serviceDetails").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#serviceDetails").append("<div class='service-imitation'><img class='img-responsive' src='theme/img/services/" + value.photo + "' style='height:150px;'/></div><div class='service-desc'><h5 class='text-center'>" + value.name + "</h5><h4 class='text-center'>&#8369;" + value.amount.toFixed(2) + "</h4><p class='text-justify'>" + value.description + "</p></div>");
                    });
                }else{
                    $("#serviceDetails").empty();
                    $("#serviceDetails").append("<li>No Service Available for Basic Spa Treatment</li>");
                }
            }
        });
    }

    function getServiceComments(code){
    	$.ajax({
            type: "GET",
            url: "web.php?service=comments&code=" + code,
            dataType: "json",
            asyc: true,
            beforeSend: function () {
                $("#serviceComments").empty();
                $("#serviceComments").append("<div class='text-center'><img src='theme/img/loader.gif'></div>");
            },
            success: function (data) {
                var count = 0;
                $("#serviceComments").empty();
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        count++;
                        $("#serviceComments").append("<div class='feed-activity-list'><div class='feed-element'><div class='media-body'><strong>"+ jQuery.timeago(value.date_created) +"</strong><div class='well'>" + value.comments + "</div></div></div></div>");
                    });
                }else{
                    $("#serviceComments").append("<div class='text-center text-danger'>No available comments for this service.</div>");
                }
            }
        }).done(function(){
        	$("#txtComment").focus();
        });
    }

    $("#txtComment").keyup(function(e){
    	if($(this).val().length > 0){
    		$("#btnComment").attr('disabled', false);
    		if(e.keyCode == '13'){
    			$("#btnComment").trigger('click');
    		}
    	}else{
			$("#btnComment").attr('disabled', true);
    	}
    });

    $("#txtComment").change(function(){
    	if($(this).val().length > 0){
    		$("#btnComment").attr('disabled', false);
            if(e.keyCode == '13'){
                $("#btnComment").trigger('click');
            }
     }else{
            $("#btnComment").attr('disabled', true);
    	}
    });

    $("#btnComment").click(function(){
        $.ajax({
            type: "POST",
            url: "web.php",
            data: { sId : $("#sId").val(), txtComment : $("#txtComment").val(), btnComment : true },
            beforeSend: function () {
            },
            success: function (data) {
            }
        }).done(function(){
            $("#txtComment").val('');
            getServiceComments($("#sId").val());
        });
    });

    tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

    function GetClock(){
        var d=new Date();
        var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
        if(nyear<1000)
            nyear+=1900;
            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

        if(nhour==0){
            ap=" AM";nhour=12;
        }else if(nhour<12){
            ap=" AM";
        }else if(nhour==12){
            ap=" PM";
        }else if(nhour>12){
            ap=" PM";nhour-=12;
        }

        if(nmin<=9)
            nmin="0"+nmin;
        if(nsec<=9)
            nsec="0"+nsec;

        document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
    }

    window.onload=function(){
        GetClock();
        setInterval(GetClock,1000);
    }

});
</script>