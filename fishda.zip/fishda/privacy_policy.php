<?php
	include("visit.php");
	visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">

	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<!-- <link href="Jumbotron%20Template%20for%20Bootstrap_files/ie10-viewport-bug-workaround.css" rel="stylesheet"> -->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li><a href="index.php">Services</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="article-content">
	            	<h2 class="title">Privacy and Policy</h2>
	            	<p>The garra rufa fish spa was discovered by two brothers in Turkey in 1800. Once these two brothers were playing near the river and jumped upon the hot spring field and were surprised to feel the army of little fish gathering around their feet and began to nibble their toes and heel gently and swarmed around the boys, tickling them but however they didn`t find their feet hurt so then onwards, they went to the hot spring every day. Surprisingly, the one brother was suffering from skin disease recovered after spent some time with the garra rufa fish. They found, that the garra rufa fish were gently removing the dead skin from the affected area and hence cured the disease. This news has spread all over the world like wildfire, and then people from everywhere came there to have unique experience with garra rufa fish. Even some people found their skin problems cured after multiple visits with the garra rufa fish. Hence it is called Doctor Fish Spa. But it got famous in Asia, Europe and America in 2006. At the beginning of its discovery this garra rufa fish is mistaken for carnivorous fish. Though this fish is happy to eat the skin of humans however it has no teeth, so it will not be dangerous or hurt human`s feet. Instead when it start suckling on the dead skin, the person can feel a sense of amusement.</p>
	            	<p>Outside of Turkey, Asian countries began exporting the fish and opening salons and spas. Europe began picking up on the craze, and then the first garra rufa fish spa opened in the United States in Alexandria, Va., in 2008. Fish treatments have been popping up in spas all over the U.S. ever since.</p>
	            </div>
	        </div>
	    </div>
    </div>
    
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
</body>
</html>
<script src="theme/js/jquery.min.js"></script>
<script src="theme/js/bootstrap.min.js"></script>