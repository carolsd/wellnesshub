<?php
    include("visit.php");
    visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">
    <link href="theme/css/font-awesome.min.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
            <h3 class="text-center text-danger" id="clockbox"></h3>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li><a href="index.php">Services</a></li>
					<li class="active"><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
                    <li><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="article-content">
	            	<h2>Reservation</h2>
                    <div class="alert alert-info text-center">
                        Afer your booking process has been done, we will check first the availability. Please kindly wait for our confirmation. If you did not receive the confirmation of your booking within 24 hours, please email us at fishdafishda@gmail.com for follow up.
                    </div>
                	<form name="frmReservation" id="frmReservation" method="POST" autocomplete="off">
                        <div class="row">
                        	<div class="col-lg-6">
                        		<h4>Customer Information</h4>
                                <div class="form-group">
	                                <label class="control-label">First Name *</label>
                                    <input type="text" placeholder="First Name" class="form-control text-caps" name="txtFirstName" id="txtFirstName" maxlength="20"/>
                                    <span class="text-danger lblFirstName_Note"></span>
	                            </div>
	                            <div class="form-group">
	                                <label class="control-label">Last Name *</label>
                                    <input type="text" placeholder="Last Name" class="form-control text-caps" name="txtLastName" id="txtLastName" maxlength="20"/>
                                    <span class="text-danger lblLastName_Note"></span>
	                            </div>
	                            <div class="form-group">
	                                <label class="control-label">Mobile *</label>
                                    <!-- <input type="text" placeholder="Mobile" class="form-control" name="txtMobile" id="txtMobile"/> -->
									<div class="input-group">
                                        <span class="input-group-addon">
                                            +63
                                        </span>
                                        <input type="text" placeholder="Mobile" class="form-control" name="txtMobile" id="txtMobile"/>
                                    </div>
                                    <span class="text-danger lblMobile_Note"></span>
	                            </div>
	                            <div class="form-group">
	                                <label class="control-label">Email (Optional)</label>
                                    <input type="email" placeholder="Email" class="form-control" name="txtEmail" id="txtEmail"/>
                                    <span class="text-danger lblEmail_Note"></span>
	                            </div>
	                            <h4>Reservation Information</h4>
	                            <!-- <div class="form-group">
	                                <label class="control-label">Date *</label>
                                    <div class='input-group date' id='datePicker'>
                                        <div class="input-append date" id="datePicker" data-date="12-02-2012" data-date-format="dd-mm-yyyy">
                                            <input type='text' class="form-control" id="txtSpaTime" name="txtSpaTime" readonly="" />
                                        </div>
                                        <span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                    </div>
                                    <span class="note-block text-danger lblSpaDate_Note"></span>
	                            </div> -->
                                <div class="form-group date">
                                    <label class="control-label">Date *</label>
                                    <!-- <input type="text" class="form-control" id="txtSpaTime" name="txtSpaTime" placeholder="HH:MM"/> -->
                                    <div class='input-group date' id='datePicker'>
                                        <input type='text' class="form-control" id="txtSpaDate" name="txtSpaDate"/>
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                    <span class="note-block text-danger lblSpaDate_Note"></span>
                                </div>
	                            <div class="form-group date">
	                                <label class="control-label">Time *</label>
                                    <!-- <input type="text" class="form-control" id="txtSpaTime" name="txtSpaTime" placeholder="HH:MM"/> -->
                                    <div class='input-group date' id='timePicker'>
                                        <input type='text' class="form-control" id="txtSpaTime" name="txtSpaTime"/>
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-time"></span>
                                        </span>
                                    </div>
                                    <span class="note-block text-danger lblSpaTime_Note"></span>
	                            </div>
                                <div class="form-group">
                                    <label class="control-label">No of Person(s) *</label>
                                    <select class="form-control" name="txtNoOfPersons" id="txtNoOfPersons">
                                        <option value="">- SELECT NO OF PERSON(S) -</option>
                                        <?php
                                            for ($count=1; $count <= 10; $count++) { 
                                                echo "<option value='".$count."'>".$count."</option>";
                                            }
                                        ?>
                                    </select>
                                    <span class="text-danger lblNoOfPersons_Note"></span>
                                </div>
	                            <div class="form-group">
	                                <label class="control-label">Special Request (Optional)</label>
                                    <textarea type="text" placeholder="Special Request" class="form-control" name="txtRemarks" id="txtRemarks"></textarea>
                                    <span class="text-danger lblRemarks_Note"></span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <h4>Services*</h4>
                                <span class="text-danger lblchkBasicPackage_Note"></span>
	                            <h4>Basic Spa Treatment</h4>
	                            <div class="form-group">
	                            	<ul id="serviceBasicData" class="nav nav-pills nav-stacked">
	                            		<?php 
                                            require("web.php");
                                            $basic = json_decode(getReservationServices(1),true);
                                            $package = json_decode(getReservationServices(2),true);
                                            foreach ($basic as $basicData) {
                                                echo "<li><label class='control-label'><input type='checkbox' name='chkServices' id='chkServices' value='" . $basicData['code'] . "'/> " . $basicData['name'] . " <i>(Php " . number_format($basicData['amount'],2) . ")</i></label><ul class='nav nav-pills nav-stacked " . $basicData['code'] . "' style='background:#f5f5f5; padding:0 20px;'></ul></li>";
                                            }
                                        ?>
	                            	</ul>
	                            </div>
	                            <h4>Package Spa Treatment</h4>
	                            <div class="form-group">
	                            	<ul id="servicePackageData" class="nav nav-pills nav-stacked">
	                            		<?php
                                            foreach ($package as $packageData) {
                                                echo "<li><label class='control-label'><input type='checkbox' name='chkServices' id='chkServices' value='" . $packageData['code'] . "'/> " . $packageData['name'] . " <i>(Php " . number_format($packageData['amount'],2) . ")</i></label><p>" . $packageData['description'] . "</p></li>";
                                            }
                                        ?>
	                            	</ul>
	                            </div>
                                <div class="form-group">
                                    <button class="btn btn-block btn-success" data-loading-text="Please wait..." type="submit" name="btnConfirm" id="btnConfirm">Confirm Reservation</button>
                                </div>
                        	</div>
                        </div>
                    </form>
	            </div>
	        </div>
	    </div>
    </div>
    
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
                <div class="col-lg-offset-4 col-lg-4 col-lg-offset-4">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="https://www.facebook.com/fishspamassage/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/fishdawellnesshub/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
    <div id="modalTestimonial" class="modal fade" role="dialog" tabindex='-1'>
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" id="serviceName"></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6" id="serviceDetails">
                                
                        </div>
                        <div class="col-lg-6">
                            <div class="panel-body" id="serviceComments">
                                
                            </div>
                            <div class="panel-footer">
                                <input type="hidden" name="sId" id="sId">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="..." name="txtComment" id="txtComment" maxlength="200">
                                    <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button" name="btnComment" id="btnComment">Post</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<link href="theme/css/bootstrap-datetimepicker-standalone.css" rel="stylesheet"/>
<script src="theme/js/jquery-2.1.1.js"></script>
<script src="theme/js/bootstrap.min.js"></script>
<script src="theme/js/moment.js"></script>
<script src="theme/js/bootstrap-datetimepicker.min.js"></script>
<script src="theme/js/jquery.mask.min.js"></script>
<script src="theme/js/fishda.js"></script>
<script type="text/javascript">
$(function() {
    var errStyle = { border : "1px solid #f00" };
    var resStyle = { border : "1px solid #ccc" };
    var maxReserve = 4; // This is the maximum number of reservation
    var serveMassue = 0;
    var chkbtn = [];
    inputNum($("#txtMobile"));
    inputDisable($("#txtSpaDate"));
    inputDisable($("#txtSpaTime"));
    inputText($("#txtFirstName"));
    inputText($("#txtLastName"));
    $("#txtMobile").mask("999 999 9999", {placeholder: "9-- --- ----"});
    $('li label').css('cursor','pointer');

    getFullDates(maxReserve);

    var new_date = moment(new Date);
    // new_date.add(2, 'days');

    $('#timePicker').datetimepicker({
        enabledHours: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21],
        format: 'LT'
    });
	
	$("#txtSpaTime").val("");
	$("#txtSpaTime").attr("placeholder","HH:MM");

    $("#frmReservation").submit(function(){
        if(servicesValidate() & personsValidate() & timeValidate() & dateValidate() & mobileValidate() & lastnameValidate() & firstnameValidate()){
            if(servicesRadioValidate()){
                // alert(serveMassue);
                // alert(chkbtn);
                var chkServicesVal = $( "#chkServices:checked" ).map(function() {
                    return $( this ).val();
                }).get().join( "|" );
                
                $.ajax({
                    type: "POST",
                    data: { txtFirstName : $("#txtFirstName").val(),txtLastName : $("#txtLastName").val(),txtMobile : $("#txtMobile").val(),txtEmail : $("#txtEmail").val(),txtSpaDate : $("#txtSpaDate").val(),txtSpaTime : $("#txtSpaTime").val(),txtNoOfPersons : $("#txtNoOfPersons").val(),txtRemarks : $("#txtRemarks").val(), chkServicesVal : chkServicesVal, chkbtnMassue : chkbtn, regReserve : true },
                    url: "reserve.php",
                    beforeSend : function(){
                        $("body").append("<div class='loading'>Loading&#8230;</div>");
                    },
                    success: function() {
                        window.location.href = "success.php";
                    }
                });
            }
        }
        return false;
    });

    $("input[type='checkbox']").change(function(){
        var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
        var rbtn = "."+$(this).val();
        if($(this).is(":checked")) {
            var a = new Date($("#txtSpaDate").val());
            $.ajax({
                type: "GET",
                data: { txtService : $(this).val(), txtDay : weekday[a.getDay()], reserveMassue : true },
                url: "web.php",
                dataType:"json",
                beforeSend : function(){
                    $(rbtn).empty();
                    $(rbtn).append("<div id='loader'></div>");
                },
                success: function(data) {
                    var count = 0;
                    count++;
                    if(Object.keys(data).length > 0){
                        $.each(data, function (key, value) {
                            $(rbtn).append("<li><label class='control-label'><input type='radio' name='" + value.service + "' value='" + value.code + "|" + value.service + "'/> " + value.name_of_employee + "</label></li>");
                        });
                        $(rbtn).append("<li><label class='control-label'><input type='radio' name='" + data[0].service + "' value='|" + data[0].service + "'/> NONE</label></li>");
                        serveMassue = serveMassue + 1;
                    }else{
                        $(rbtn).empty();
                    }
                }
            });
        }else{
            if(serveMassue > 0){
                serveMassue = serveMassue - 1;
            }
            $(rbtn).empty();
            $(rbtn).append("");
        }
    });

    function firstnameValidate(){
        if($("#txtFirstName").val() == ""){
            $("#txtFirstName").css(errStyle);
            $(".lblFirstName_Note").text("Please type your First Name");
            $("#txtFirstName").focus();
        }else{
            if($("#txtFirstName").val().length > 20){
                $("#txtFirstName").css(errStyle);
                $(".lblFirstName_Note").text("Firstname must be maximum 20 characters length");
                $("#txtFirstName").focus();
            }else{
                $("#txtFirstName").css(resStyle);
                $("#txtFirstName").text("");
                $(".lblFirstName_Note").text("");
                return true;
            }
        }
    }

    function lastnameValidate(){
        if($("#txtLastName").val() == ""){
            $("#txtLastName").css(errStyle);
            $(".lblLastName_Note").text("Please type your Last Name");
            $("#txtLastName").focus();
        }else{
            if($("#txtLastName").val().length > 20){
                $("#txtLastName").css(errStyle);
                $(".lblLastName_Note").text("Lastname must be maximum 20 characters length");
                $("#txtLastName").focus();
            }else{
                $("#txtLastName").css(resStyle);
                $("#txtLastName").text("");
                $(".lblLastName_Note").text("");
                return true;
            }
        }
    }

    function mobileValidate(){
        if($("#txtMobile").val() == ""){
            $("#txtMobile").css(errStyle);
            $(".lblMobile_Note").text("Please type your Mobile Number");
            $("#txtMobile").focus();
        }else{
            if($("#txtMobile").val().slice(0,1) != 9){
                $("#txtMobile").css(errStyle);
                $(".lblMobile_Note").text("Invalid Mobile number format");
                $("#txtMobile").focus();
            }else if($("#txtMobile").val().length < 10){
                $("#txtMobile").css(errStyle);
                $(".lblMobile_Note").text("Mobile number must be 10 characters length");
                $("#txtMobile").focus();
            }else{
                $("#txtMobile").css(resStyle);
				$("#txtMobile").text("");
				$(".lblMobile_Note").text("");
				return true;
            }
        }
    }

    function dateValidate(){
        if($("#txtSpaDate").val() == ""){
            $("#txtSpaDate").css(errStyle);
            $(".lblSpaDate_Note").text("Please select your spa treatment date");
            $("#txtSpaDate").focus();
        }else{
            $("#txtSpaDate").css(resStyle);
            $("#txtSpaDate").text("");
            $(".lblSpaDate_Note").text("");
            return true;
        }
    }

    function timeValidate(){
        if($("#txtSpaTime").val() == ""){
            $("#txtSpaTime").css(errStyle);
            $(".lblSpaTime_Note").text("Please type your spa treatment prepared time");
            $("#txtSpaTime").focus();
        }else{
            $("#txtSpaTime").css(resStyle);
            $("#txtSpaTime").text("");
            $(".lblSpaTime_Note").text("");
            return true;
        }
    }

    function personsValidate(){
        if($("#txtNoOfPersons").val() == ""){
            $("#txtNoOfPersons").css(errStyle);
            $(".lblNoOfPersons_Note").text("Please type your Number of Person(s)");
            $("#txtNoOfPersons").focus();
        }else{
            $("#txtNoOfPersons").css(resStyle);
            $(".lblNoOfPersons_Note").text("");
            return true;
        }
    }

    function servicesValidate(){
        if(!validateChkServices()){
            $(".lblchkBasicPackage_Note").text("Please select Basic or Package Spa Treatment to complete the reservation.");
        }else{
            $(".lblchkBasicPackage_Note").text("");
            return true;
        }
    } 
    
    function servicesRadioValidate(){
        if(serveMassue == 0){
            $(".lblchkBasicPackage_Note").text("");
            return true;
        }else{
            if(!validateRbtnMassue()){
                $(".lblchkBasicPackage_Note").text("Please select one of the Massue option.");
            }else{
                $(".lblchkBasicPackage_Note").text("");
                return true;
            }
        }
    } 
	
	function validateChkServices(){
        var isValid = false;
        var allRows = $("input[type='checkbox']");
        for (var i=0; i < allRows.length; i++) {
            if (allRows[i].type == 'checkbox' && allRows[i].name == 'chkServices') {
                if (allRows[i].checked == true) {
                       return true;
                }
            }
        }
        return isValid;
    }

    function validateRbtnMassue(){
        var isValid = false;
        // var chkbtn = [];
        var chkval = "";
        var allRows = $("input[type='radio']:checked");
        for (var i=0; i < allRows.length; i++) {
            if(allRows[i].name != chkval){
                chkval = allRows[i].value;
                chkbtn.push(chkval);
                if(chkbtn.length == serveMassue){
                    return true;
                }
            }
        }
        return isValid;
    }

    tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

    function GetClock(){
        var d=new Date();
        var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getYear();
        if(nyear<1000)
            nyear+=1900;
            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

        if(nhour==0){
            ap=" AM";nhour=12;
        }else if(nhour<12){
            ap=" AM";
        }else if(nhour==12){
            ap=" PM";
        }else if(nhour>12){
            ap=" PM";nhour-=12;
        }

        if(nmin<=9)
            nmin="0"+nmin;
        if(nsec<=9)
            nsec="0"+nsec;

        document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
    }

    window.onload=function(){
        GetClock();
        setInterval(GetClock,1000);
    }

    function getFullDates(maxReserve){ // Get Full Dates Data
        var dataArray = [];
        $.ajax({
            type: "GET",
            url: "web.php?maxReserve=" + maxReserve,
            dataType: "json",
            asyc: true,
            success: function (data) {
                var count = 0;
                if(Object.keys(data).length > 0){
                    $.each(data, function (key, value) {
                        dataArray.push(value.booking_date);
                    });

                    $('#datePicker').datetimepicker({
                        format: 'MM/DD/YYYY',
                        minDate: new_date,
                        disabledDates: dataArray
                    });
					
					$('#txtSpaDate').val('');
					$('#txtSpaDate').attr("placeholder","MM/DD/YYYY");
                }else{
                    $('#datePicker').datetimepicker({
                        format: 'L',
                        minDate: new_date
                    });
                }
            }
        });
    }
});
</script>