<?php
	if(isset($_POST['regReserve'])){

		require("admin/config/Database.php");
		require("admin/lib/Reservation.php");
		require("admin/lib/SMS/SmsGateway.php");
		$reservation = new Reservation();

		$code = $reservation->generateReservationCode();
		$date = date("Y-m-d H:i:s");

		$cResData = array("code" => $code,"first_name" => $_POST['txtFirstName'],"last_name" => $_POST['txtLastName'],"mobile" => "+63 ".$_POST['txtMobile'],"email" => $_POST['txtEmail'],"booking_date" => $_POST['txtSpaDate'],"booking_time" => $_POST['txtSpaTime'],"count" => $_POST['txtNoOfPersons'],"remarks" => $_POST['txtRemarks'],"date_created1" => $date,"date_modified1" => $date,"status1" => "1");

		$sql = "INSERT INTO booking(idbooking,code,first_name,last_name,mobile,email,booking_date,booking_time,count,remarks,date_created,date_modified,status) VALUES('',?,?,?,?,?,?,?,?,?,?,?,'1')";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->bind_param("sssssssisss",$cResData['code'],$cResData['first_name'],$cResData['last_name'],$cResData['mobile'],$cResData['email'],$cResData['booking_date'],$cResData['booking_time'],$cResData['count'],$cResData['remarks'],$cResData['date_created1'],$cResData['date_modified1']);
		$stmt->execute();
		$stmt->close();

		$services = explode("|",$_POST['chkServicesVal']);
		$m = 0;
		$s=0;
		while($s < count($services)){
			if(isset($_POST['chkbtnMassue'])){
				$massue = $_POST['chkbtnMassue'];
				if($m == $s){
					if($m < count($massue)){
						$mres = explode("|",$massue[$m]);
						$mResData[] = array($mres[0] => $mres[1]);
						if($mres[1] == $services[$s]){
							$account = $mres[0];
						}else{
							$account = "";
						}
						$m++;
					}else{
						$account = "";
					}
					$sResData = array("booking" => $code,"services" => $services[$s],'account' => $account,"date_created2" => $date,"date_modified2" => $date,"status2" => "1");
				}else{
					$sResData = array("booking" => $code,"services" => $services[$s],'account' => '',"date_created2" => $date,"date_modified2" => $date,"status2" => "1");
				}
			}else{
				$sResData = array("booking" => $code,"services" => $services[$s],'account' => '',"date_created2" => $date,"date_modified2" => $date,"status2" => "1");
			}
			$s++;
			$resLogData[] = array_merge($cResData,$sResData);

			$sql = "INSERT INTO booking_services(booking,service,account,date_created,date_modified,status) VALUES(?,?,?,?,?,'1')";
			$stmt = $db->prepare($sql);
			if($stmt === false){
				trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
			}
			$stmt->bind_param("sssss",$sResData['booking'],$sResData['services'],$sResData['account'],$sResData['date_created2'],$sResData['date_modified2']);
			$stmt->execute();
			createLogs($code,json_encode($resLogData),1);
			session_start();
			$_SESSION['resRefNo'] = $code;
		}
		$stmt->close();


		// GET SMS GATEWAY CREDENTIALS
		$sql = "SELECT device,email,password FROM smsgateway ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}

		$stmt->execute();
		$stmt->bind_result($device,$email,$password);
		$stmt->store_result();
		$stmt->fetch();
		$stmt->close();

		// SMS DETAILS for SPA Reservation
		$to = str_replace("+63","0",$cResData['mobile']);
		$message="Your booking with reference number ".$code." has been done, we will check first the availability. Please kindly wait for our confirmation. If you did not receive the confirmation of your booking within 24 hours, please email us at fishdafishda@gmail.com";
		$options=array('send_at' => strtotime('+1 seconds'),'expires_at' => strtotime('+1 hour'));

		$smsGateway= new SmsGateway($email,$password);
		$response = $smsGateway->sendMessageToNumber($to, $message, $device, $options);
		$smsResData = array("to" => $to,"message" => $message,"device" => $device,"options" => $options);
		createLogs($code,json_encode($smsResData),6);
		if(isset($_SESSION["cart_item"])){
			unset($_SESSION["cart_item"]);
		}
	}else{
		header("Location:index.php");
	}

	function createLogs($code,$log,$status){
		require("admin/config/Database.php");
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO logs(code,log,date_created,date_modified,status) VALUES(?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ssssi",$code,$log,$date,$date,$status);
		$stmt->execute();
		$stmt->close();
	}
?>