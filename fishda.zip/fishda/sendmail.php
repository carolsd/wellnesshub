<?php
	if(isset($_POST['contData'])){

		require("admin/config/Database.php");
		$date = date("Y-m-d H:i:s");

		$contData = array("code" => $code,"fullname" => $_POST['txtFullName'],"email" => $_POST['txtEmail'],"mobile" => "+63 ".$_POST['txtMobile'],"messages" => $_POST['txtMessage']);
		
		// Email Content
		$subject = "WEBSITE CONTACT PAGE MAIL";
		$message = "<p>WEBSITE CONTACT PAGE MAIL</p><br/>";
		$message .= "<br/><p>FULL NAME: ".$contData['fullname']."</p>";
		$message .= "<br/><p>EMAIL: ".$contData['email']."</p>";
		$message .= "<br/><p>MOBILE NUMBER: ".$contData['mobile']."</p>";
		$message .= "<br/><p>MESSAGE: ".$_POST['messages']."</p>";
					
		$header = "MIME-Version: 1.0" . "\r\n";
		$header .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$header .= 'From: fishdawellnesshub@gmail.com' . "\r\n";
		
		$to = "fishdawellnesshub@gmail.com";
		$others = ""; // WEB MASTER'S EMAIL
		mail($to,$subject,$message,$header,$others);
		// End Email Content

		createLogs(get_client_ip(),json_encode($contData),9); // Create Log Instance
	}else{
		header("Location:contact.php");
	}

	function createLogs($code,$log,$status){ // Create Log Functions
		require("admin/config/Database.php");
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO logs(code,log,date_created,date_modified,status) VALUES(?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ssssi",$code,$log,$date,$date,$status);
		$stmt->execute();
		$stmt->close();
	}

	function get_client_ip() { // Get Guest's IP ADDRESS
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP']))
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    else if(isset($_SERVER['HTTP_X_FORWARDED']))
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    else if(isset($_SERVER['HTTP_FORWARDED']))
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    else if(isset($_SERVER['REMOTE_ADDR']))
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    else
	        $ipaddress = 'UNKNOWN';
	    return $ipaddress;
	}
?>