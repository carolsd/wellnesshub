<?php
	header("Refresh:3;url=index.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="article-content">
	            	<h1 class="text-center text-success">Success!</h1>
	            	<?php
	            		session_start();
		            	if(isset($_SESSION['resRefNo'])){
		            		echo "<h1 class='text-center text-success'>Reference Number: ".$_SESSION['resRefNo']."</h1>";
		            	}
	            	?>
					<p class="text-center text-success">please wait for few seconds while redirecting you to fishda website.</p>
	            </div>
	        </div>
	    </div>
    </div>
    
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
</body>
</html>