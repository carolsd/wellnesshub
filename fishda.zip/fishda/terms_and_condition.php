<?php
	include("visit.php");
	visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="description" content="Fish SPA">
	<meta name="author" content="Carol Sto. Domingo, Sukpal Deol, Lady Christin Friginal">
	<link rel="icon" href="theme/img/fishda.png">

	<title>FISHDA SPA</title>

	<link href="theme/css/bootstrap.css" rel="stylesheet">
	<link href="theme/css/fishdaweb.css" rel="stylesheet">
	<link href="theme/css/font-awesome.min.css" rel="stylesheet">

	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<!-- <link href="Jumbotron%20Template%20for%20Bootstrap_files/ie10-viewport-bug-workaround.css" rel="stylesheet"> -->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
    <div class="brand">
        <img src="theme/img/fishda.png"/>
    </div>
    <nav class="navbar navbar-default" role="navigation">
    	<div class="container">
	        <div class="navbar-header">
	            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                <span class="sr-only">Toggle navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>
	            <a class="navbar-brand" href="/"><img src="theme/img/fishda_small.png"/></a>
	        </div>
	        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	            <ul class="nav navbar-nav">
	                <li><a href="index.php">Services</a></li>
					<li><a href="reservation.php">Reservation</a></li>
					<li><a href="gallery.php">Gallery</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
					<li><a href="cart.php"><i class="fa fa-cart"></i><?php echo (isset($_SESSION['cart_item'])) ? count($_SESSION['cart_item']) : "0"; ?> Cart</a></li>
	            </ul>
	        </div>
    	</div>
    </nav>
    <div class="container">
    	<div class="row">
	        <div class="col-lg-12">
	            <div class="article-content">
	            	<h2 class="title">Terms and Conditions</h2>
					<p>Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service.  By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service.</p>
					<h4>1.	Introduction</h4>
					<p>These Website Standard Terms and Conditions written on this webpage shall manage your use of this website. These Terms will be applied fully and affect to your use of this Website. By using this Website, you agreed to accept all terms and conditions written in here. You must not use this Website if you disagree with any of these Website Standard Terms and Conditions.</p>
					<h4>2. Intellectual Property Rights</h4>
					<p>Other than the content you own, under these Terms, and/or its licensors own all the intellectual property rights and materials contained in this Website.
					You are granted limited license only for purposes of viewing the material contained on this Website.<p>
					<h4>3. Restrictions</h4>
					<p>You are specifically restricted from all of the following</p>
					<ul>
						<li>Publishing any Website material in any other media;</li>
						<li>Selling, sublicensing and/or otherwise commercializing any Website material;</li>
						<li>Publicly performing and/or showing any Website material;</li>
						<li>Using this Website in any way that is or may be damaging to this Website;</li>
						<li>Using this Website in any way that impacts user access to this Website;</li>
						<li>using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity;</li>
						<li>Engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website;</li>
						<li>Using this Website to engage in any advertising or marketing.</li>
					</ul>
					<p>Certain areas of this Website are restricted from being access by you and may further restrict access by you to any areas of this Website, at any time, in absolute discretion. Any user ID and password you may have for this Website are confidential and you must maintain confidentiality as well.</p>
					<h4>4. Your Content</h4>
					<p>In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant a non-exclusive, worldwide irrevocable, sub licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media.</p>
					<p>Your Content must be your own and must not be invading any third-party’s rights.  It reserves the right to remove any of Your Content from this Website at any time without notice.</p>
					<h4>5. No warranties</h4>
					<p>This Website is provided “as is,” with all faults, and express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you.</p>
					<h4>6. Limitation of liability</h4>
					<p>In no event shall , nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract.  , including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.</p>
					<h4>7. Indemnification</h4>
					<p>You hereby indemnify to the fullest extent  from and against any and/or all liabilities, costs, demands, causes of action, damages and expenses arising in any way related to your breach of any of the provisions of these Terms.</p>
					<h4>8. Severability</h4>
					<p>If any provision of these Terms is found to be invalid under any applicable law, such provisions shall be deleted without affecting the remaining provisions herein.</p>
					<h4>9. Variation of Terms</h4>
					<p>It is permitted to revise these Terms at any time as it sees fit, and by using this website you are expected to review these Terms on a regular basis.</p>
					<h4>10. Assignment</h4>
					<p>These are allowed to assign, transfer, and subcontract its rights and/or obligations under these Terms without any notification. However, you are not allowed to assign, transfer, or subcontract any of your rights and/or obligations under these Terms.</p>
					<h4>11. Entire Agreement</h4>
					<p>These Terms constitute the entire agreement between and you in relation to your use of this Website, and supersede all prior agreements and understandings.</p>
					<h4>12. Governing Law and Jurisdiction</h4>
					<p>These Terms will be governed by and interpreted in accordance with the laws of the State of , and you submit to the non-exclusive jurisdiction of the state and federal courts located in  for the resolution of any disputes.</p>
					<h4>THE CANCELLATION POLICIES</h4>
					<ul>
						<li>We recommend that you call the Fishda Spa in advance of your arrival to schedule your appointment.</li>
						<li>Please arrive at The Spa at least 5 minutes prior to your appointment time. Late arrivals will result in shortened treatment times, and appointments will only be held for 15 minutes.</li>
						<li>Cancellation of Reservation is via text or email.</li>
						<li>Guests under 18 years of age must be accompanied by an adult during their treatment.</li>
						<li>Guests under 18 who are not receiving treatment should not be present during any other guest's spa treatments. No exceptions.</li>
						<li>All information exchanged during our spa sessions will be kept completely confidential.</li>
						<li>By making an appointment for these services, you agree to these terms.</li>
					</ul>
					<h4>Legal Disclaimer</h4>
					<p>In addition to our rights of disclosure as mentioned hereinabove, we may also disclose the Data required by law, or court order. Or as requested by the government or law enforcement authorities, or in the good faith that disclosure is otherwise necessary or advisable including and without limitation to protect the rights or properties of Fishda Spa. This also applies when we have reason to believe that disclosing the Data is necessary to identify, contact or bring legal action against someone who may be causing interference with our rights or properties, whether intentionally or otherwise, or when anyone else could be harmed by such activities.</p>
	            </div>
	        </div>
	    </div>
    </div>
    
    <div class="container">
	    <footer>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="terms_and_condition.php">Terms and Condition</a></li>
                    </ul>
                </div>
                <div class="col-lg-offset-4 col-lg-4 col-lg-offset-4">
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
	        <div class="row">
                <p class="text-muted text-center">Copyright &copy; 2016 Fishda Wellness Hub</p>
	        </div>
		</footer>
    </div>
</body>
</html>
<script src="theme/js/jquery.min.js"></script>
<script src="theme/js/bootstrap.min.js"></script>