// Class text-caps in input tags will convert the text from lower case to upper case

$(".text-caps").keyup(function(){
    this.value=this.value.toUpperCase();
});

$(".text-caps").change(function(){
    this.value=this.value.toUpperCase();
});

// End of text-caps

// It allows numeric in input field userfull for currency

(function(){
	inputAmount = function(inputCont){
		inputCont.keydown(function(event) {
			// Allow special chars + arrows */
			if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 110
				|| event.keyCode == 27 || event.keyCode == 13
				|| (event.keyCode == 65 && event.ctrlKey === true)
				|| (event.keyCode >= 35 && event.keyCode <= 39) || (event.ctrlKey && event.keyCode == 86) || (event.keyCode == 190)){
					return;
			}else {
				// If it's not a number stop the keypress
				if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
					event.preventDefault();
				}
			}
		});
	};
})();

// End of inputAmount

// It allows numeric in input field

(function(){
	inputNum = function(inputCont){
		inputCont.keydown(function(event) {
			// Allow special chars + arrows */
			if (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 110
				|| event.keyCode == 27 || event.keyCode == 13
				|| (event.keyCode == 65 && event.ctrlKey === true)
				|| (event.keyCode >= 35 && event.keyCode <= 39) || (event.ctrlKey && event.keyCode == 86) || (event.keyCode == 190)){
					return;
			}else {
				// If it's not a number stop the keypress
				if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
					event.preventDefault();
				}
			}
		});
	};
})();

// End of inputNum

// It allows numeric in input field userfull for currency

(function(){
	inputDisable = function(inputCont){
		inputCont.keydown(function(event) {
			if(event.keyCode == 9){
				return;
			}else{
				event.preventDefault();
			}
		});
	};
})();

// End of inputAmount

// It allows alphabet in input field

(function(){
	inputText = function(inputCont){
		inputCont.keydown(function(event) {
			// // Allow special chars + arrows */
			// if (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 110
			// 	|| event.keyCode == 27 || event.keyCode == 13
			// 	|| (event.keyCode == 65 && event.ctrlKey === true)
			// 	|| (event.keyCode >= 35 && event.keyCode <= 39) || (event.ctrlKey && event.keyCode == 86) || (event.keyCode == 190)){
			// 		return;
			// }else {
				// If it's not a number stop the keypress
				// if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
				if (((event.keyCode >= 37 && event.keyCode <= 40) || (event.keyCode >= 65 && event.keyCode <= 90) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 32 || event.keyCode == 46)) {
					return;
				}else{
					event.preventDefault();
				}
			// }
		});
	};
})();
// End of inputNum