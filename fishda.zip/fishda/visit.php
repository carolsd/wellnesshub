<?php

	function visit(){
		$ip = get_client_ip();
		// $urlBrowser = json_encode(array_merge(array('url' => url()),browser()));
		createLogs($ip,browser()[2],2);
	}

	function get_client_ip() { // Get Guest's IP ADDRESS
	    $ipaddress = '';
	    if (isset($_SERVER['HTTP_CLIENT_IP']))
	        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	    else if(isset($_SERVER['HTTP_X_FORWARDED']))
	        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
	        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	    else if(isset($_SERVER['HTTP_FORWARDED']))
	        $ipaddress = $_SERVER['HTTP_FORWARDED'];
	    else if(isset($_SERVER['REMOTE_ADDR']))
	        $ipaddress = $_SERVER['REMOTE_ADDR'];
	    else
	        $ipaddress = 'UNKNOWN';
	    return $ipaddress;
	}

	function browser() {
		$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
		// you can add different browsers with the same way ..
		if(preg_match('/(chromium)[ \/]([\w.]+)/', $ua))
				$browser = 'chromium';
		elseif(preg_match('/(chrome)[ \/]([\w.]+)/', $ua))
				$browser = 'chrome';
		elseif(preg_match('/(safari)[ \/]([\w.]+)/', $ua))
				$browser = 'safari';
		elseif(preg_match('/(opera)[ \/]([\w.]+)/', $ua))
				$browser = 'opera';
		elseif(preg_match('/(msie)[ \/]([\w.]+)/', $ua))
				$browser = 'msie';
		elseif(preg_match('/(mozilla)[ \/]([\w.]+)/', $ua))
				$browser = 'mozilla';

		preg_match('/('.$browser.')[ \/]([\w]+)/', $ua, $version);

		return array($browser,$version[2], 'name'=>$browser,'version'=>$version[2],$ua);
	}

	function url(){
	    if(isset($_SERVER['HTTPS'])){
	        $protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
	    }
	    else{
	        $protocol = 'http';
	    }
	    return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	}

	function createLogs($code,$log,$status){ // Create Log Functions
		require("admin/config/Database.php");
		$date = date("Y-m-d H:i:s");
		$sql = "INSERT INTO logs(code,log,date_created,date_modified,status) VALUES(?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ssssi",$code,$log,$date,$date,$status);
		$stmt->execute();
		$stmt->close();
	}
?>