<?php
	// include('visit.php');
	require("admin/lib/Services.php");
	$services = new Services();

	if(isset($_GET['services'])){
		if($_GET['type'] == "reservation"){
			if($_GET['services'] == "basic"){
				echo getReservationServices(1);
			}else if($_GET['services'] == "package"){
				echo getReservationServices(2);
			}
		}else if($_GET['type'] == "home"){
			if($_GET['services'] == "basic"){
				echo getServices(1);
			}else if($_GET['services'] == "package"){
				echo getServices(2);
			}
		}
	}else if(isset($_GET['service'])){
		if($_GET['service'] == "details"){
			echo getServiceDetails($_GET['code']);
		}else if($_GET['service'] == "comments"){
			echo getServiceComments($_GET['code']);
		}
	}else if(isset($_POST['btnComment'])){
		newComments($_POST['sId']);
	}else if(isset($_GET['gallery'])){
		if($_GET['gallery'] == "list"){
			echo getGalleryList();
		}
	}else if(isset($_GET['maxReserve'])){
		echo getFullDates($_GET['maxReserve']);
	}else if(isset($_GET['reserveDate'])){
		echo getReserveCount($_GET['reserveDate']);
	}else if(isset($_GET['reserveMassue'])){
		echo getMassuePerDay($_GET['txtService'],$_GET['txtDay']);
	}else if(isset($_GET['action'])){
		session_start();
		if(!empty($_GET["action"])) {
			switch($_GET["action"]) {
				case "add":
					$serviceByCode = json_decode(getServiceDetails($_GET['code']),true);
					print_r($serviceByCode);
					$itemArray = array($serviceByCode[0]["code"]=>array('name'=>$serviceByCode[0]["name"], 'code'=>$serviceByCode[0]["code"], 'description'=>$serviceByCode[0]["description"], 'amount'=>$serviceByCode[0]["amount"]));
					
					echo $serviceByCode["description"];
					if(!empty($_SESSION["cart_item"])) {
						if(in_array($serviceByCode[0]["code"],$_SESSION["cart_item"])) {
							foreach($_SESSION["cart_item"] as $k => $v) {
									if($serviceByCode[0]["code"] == $k)
										$_SESSION["cart_item"][$k]["description"] = $_POST["description"];
							}
						} else {
							$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
						}
					} else {
						$_SESSION["cart_item"] = $itemArray;
					}
					header("Location:index.php");
				break;
				case "remove":
					if(!empty($_SESSION["cart_item"])) {
						foreach($_SESSION["cart_item"] as $k => $v) {
								if($_GET["code"] == $k)
									unset($_SESSION["cart_item"][$k]);				
								if(empty($_SESSION["cart_item"]))
									unset($_SESSION["cart_item"]);
						}
					}
					header("Location:cart.php");
				break;
				case "empty":
					unset($_SESSION["cart_item"]);
				break;	
			}
		}
	}

	function getReservationServices($type){
		require("admin/config/Database.php");
		$sql = "SELECT code,type,name,description,photo,amount,timerange FROM services WHERE type = ? AND status !=2 AND status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$type);
		$stmt->execute();
		$stmt->bind_result($code,$type,$name,$description,$photo,$amount,$timerange);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"amount" => $amount,"timerange" => $timerange);
			}
			$stmt->close();
		}else{
			$resData = "";
		}

		return json_encode($resData);
	}

	function getServices($type){
		require("admin/config/Database.php");
		$sql = "SELECT code,type,name,description,photo,amount,timerange FROM services WHERE type = ? AND status !=2 AND status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$type);
		$stmt->execute();
		$stmt->bind_result($code,$type,$name,$description,$photo,$amount,$timerange);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"amount" => $amount,"timerange" => $timerange);
			}
			$stmt->close();
		}else{
			$resData = "";
		}

		return json_encode($resData);
	}

	function getServiceDetails($code){
		require("admin/config/Database.php");
		$sql = "SELECT idservices,code,type,name,description,photo,timerange,amount,date_created,date_modified,CASE WHEN status = 0 THEN 'inverse|DEACTIVATED' WHEN status = 1 THEN 'success|ACTIVE' WHEN status = 2 THEN 'warning|PENDING' END AS sStatus FROM services WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idservices,$code,$type,$name,$description,$photo,$timerange,$amount,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			$resData[] = array("idservices" => $idservices,"code" => $code,"type" => $type,"name" => $name,"description" => $description,"photo" => $photo,"timerange" => $timerange,"amount" => $amount,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}else{
			return $resData = "";
		}
		return json_encode($resData);
	}

	function getServiceComments($code){
		require("admin/config/Database.php");
		$sql = "SELECT c.comments, c.date_created FROM services s JOIN comments c ON s.code=c.services WHERE s.code = ? ORDER BY c.date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($comments,$date_created);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$resData[] = array("comments" => $comments,"date_created" => $date_created);
			}
			$stmt->close();
		}else{
			$resData = "";
		}
		return json_encode($resData);
	}

	function newComments($service){ // Create Comments
		require("admin/config/Database.php");
		$date = date("Y-m-d H:i:s");
		$code = "CO".date('ymdHis');
		$status = 1;
		$sql = "INSERT INTO comments(code,services,comments,date_created,date_modified,status) VALUES(?,?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("sssssi",$code,$service,$_POST['txtComment'],$date,$date,$status);
		$stmt->execute();
		$stmt->close();

		session_start();
		$logData = json_encode(array_merge(array('ip' => get_client_ip()),getCommentDetails($code)));
		$util->createLogs($code,$logData,10);
	}

	function getCommentDetails($code){
		require("admin/config/Database.php");
		$sql = "SELECT idcomments,code,services,comments,date_created,date_modified,status FROM comments WHERE code = ? AND status !=0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$code);
		$stmt->execute();
		$stmt->bind_result($idcomments,$code,$services,$comments,$date_created,$date_modified,$status);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			$stmt->fetch();
			return $resData = array("idcomments" => $idcomments,"code" => $code,"services" => $services,"comments" => $comments,"date_created" => $date_created,"date_modified" => $date_modified,"status" => $status);
			$stmt->close();
		}else{
			return $stmt->num_rows;
		}
	}

	function getGalleryList(){
		require("admin/config/Database.php");
		$sql = "SELECT code,photo FROM gallery WHERE status !=0 ORDER BY date_created DESC";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->execute();
		$stmt->bind_result($code,$photo);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$galData[] = array("code" => $code,"photo" => $photo);
			}
			$stmt->close();
			return json_encode($galData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	function getReserveCount($date){
		require("admin/config/Database.php");
		$sql = "SELECT booking_date,SUM(count) AS count FROM booking WHERE booking_date = ? AND status = 2";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("s",$date);
		$stmt->execute();
		$stmt->bind_result($booking_date,$count);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$bookData[] = array("booking_date" => $booking_date,"count" => $count);
			}
			$stmt->close();
			return json_encode($bookData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	function getFullDates($maxReserve){
		require("admin/config/Database.php");
		$sql = "SELECT booking_date,count FROM booking WHERE count >= ? AND status = 2";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("i",$maxReserve);
		$stmt->execute();
		$stmt->bind_result($booking_date,$count);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$oldDate = explode("/",$booking_date);
				$newDate = $oldDate[2]."-".$oldDate[0]."-".$oldDate[1];
				$bookData[] = array("booking_date" => $newDate,"count" => $count);
			}
			$stmt->close();
			return json_encode($bookData);
		}else{
			return json_encode($stmt->num_rows);
		}
	}

	function getMassuePerDay($service,$day){
		require("admin/config/Database.php");
		$sql = "SELECT a.code, a.name_of_employee, a_sc.day, a_s.service FROM account a JOIN account_schedule a_sc ON a.code = a_sc.account JOIN account_services a_s ON a.code = a_s.account WHERE a_s.service = ? AND a_sc.day = ? AND a.status != 0";
		$stmt = $db->prepare($sql);

		if($stmt === false){
			trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
		}
		
		$stmt->bind_param("ss",$service,$day);
		$stmt->execute();
		$stmt->bind_result($code,$name_of_employee,$day,$service);
		$stmt->store_result();
		if($stmt->num_rows > 0){
			while($stmt->fetch()){
				$massueData[] = array("code" => $code,"name_of_employee" => $name_of_employee,"day" => $day,"service" => $service);
			}
			$stmt->close();
			return json_encode($massueData);
		}
	}

	// function createLogs($code,$log,$status){ // Create Log Functions
	// 	require("admin/config/Database.php");
	// 	$date = date("Y-m-d H:i:s");
	// 	$sql = "INSERT INTO logs(code,log,date_created,date_modified,status) VALUES(?,?,?,?,?)";
	// 	$stmt = $db->prepare($sql);

	// 	if($stmt === false){
	// 		trigger_error("Wrong SQL: ".$sql." ERROR: ".$db->error,E_USER_ERROR);
	// 	}
		
	// 	$stmt->bind_param("ssssi",$code,$log,$date,$date,$status);
	// 	$stmt->execute();
	// 	$stmt->close();
	// }

	// function get_client_ip() { // Get Guest's IP ADDRESS
	//     $ipaddress = '';
	//     if (isset($_SERVER['HTTP_CLIENT_IP']))
	//         $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	//     else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	//         $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	//     else if(isset($_SERVER['HTTP_X_FORWARDED']))
	//         $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	//     else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
	//         $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	//     else if(isset($_SERVER['HTTP_FORWARDED']))
	//         $ipaddress = $_SERVER['HTTP_FORWARDED'];
	//     else if(isset($_SERVER['REMOTE_ADDR']))
	//         $ipaddress = $_SERVER['REMOTE_ADDR'];
	//     else
	//         $ipaddress = 'UNKNOWN';
	//     return $ipaddress;
	// }
?>